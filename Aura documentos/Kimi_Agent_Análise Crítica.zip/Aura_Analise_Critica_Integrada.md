# ANALISE CRITICA INTEGRADA: PROJETO AURA
## Plataforma SaaS de Gestao e Venda de Entretenimento

**Data:** Maio de 2025
**Documentos Analisados:** 14 documentos, 300+ paginas (Plano Estrategico, Relatorio de Produto, D1 a D12)
**Metodologia:** Analise paralela em 4 dimensoes (Estrategia, Tecnologia, Produto, Riscos)

---

# RESUMO EXECUTIVO MESTRE

O projeto Aura e uma plataforma SaaS de ticketing e gestao de eventos com uma proposta de valor conceitualmente valida — split de pagamentos e white label em um mercado dominado pela Sympla. Contudo, apos analise critica de seus 14 documentos sob quatro dimensoes especializadas, emergem conclusoes que vao desde a cautela ate o alerta grave.

**O projeto esta significativamente mais atrasado e vulneravel do que seus documentos sugerem.** O frontend de 66 paginas, apesar de visualmente impressionante, opera 90% com dados mockados. O backend e inexistente (zero tabelas, zero APIs). O gateway de pagamento — componente critico de uma plataforma de ticketing — nao foi definido. As projecoes financeiras oscilam entre o otimismo ingenuo (R$ 8,88M/ano) e a realidade conservadora (R$ 275K/ano), um gap de 32x que revela incerteza estrategica profunda.

**O risco mais critico, porem, nao esta nos numeros — esta na regulamentacao.** A atividade de split de pagamentos e intermediacao financeira que o projeto propoe pode configurar crime de exercicio ilegal de intermediacao financeira (Lei 7.492/1986, art. 7o), punivel com reclusao de 2 a 6 anos. Nenhum dos 14 documentos menciona consultoria juridica em direito bancario ou autorizacao junto ao BACEN.

**Veredicto geral:** O Aura possui diferenciais conceituais reais, um frontend valioso e documentacao extensa, mas opera sob uma combinacao perigosa de otimismo financeiro, divida tecnica massiva, ignorancia regulatoria e ausencia de equipe. A chance de falencia ou sancao em 12 meses, na forma atual, e **ALTA**. A chance de se tornar uma operacao sustentavel de R$ 1-3M/ano, com pivot estrategico serio e investimento adequado, e **MEDIA-BAIXA**.

---

# 1. MATRIZ DE RISCOS INTEGRADA

| # | Risco | Severidade | Probabilidade | Status no Projeto |
|---|-------|-----------|---------------|-------------------|
| 1 | **Regulamentacao BACEN** — Split de pagamentos pode configurar IP ilegal | CRITICA | Alta | NAO MAPEADO |
| 2 | **LGPD** — Coleta de dados sensiveis sem compliance estruturado | CRITICA | Alta | Mencionado 1x |
| 3 | **Gateway indefinido** — Plataforma de pagamentos sem gateway | CRITICA | Certa | Consciente |
| 4 | **Ilusao do 95% pronto** — Frontend mockado, backend inexistente | ALTA | Certa | Parcialmente mapeado |
| 5 | **Projecoes irreais** — Gap 32x entre cenarios otimista e conservador | ALTA | Certa | Ignorado |
| 6 | **Race condition em webhooks** — Tickets duplicados, pagamentos perdidos | ALTA | Alta | NAO MAPEADO |
| 7 | **Vazamento de dados via RLS** — Policies com vulnerabilidades | ALTA | Media | NAO MAPEADO |
| 8 | **Conta Stripe bloqueada** — Eventos = high risk para gateways | ALTA | Media | Parcialmente mapeado |
| 9 | **Apenas 1 pessoa** — Doenca/desistencia = fim do projeto | ALTA | Media | Ignorado |
| 10 | **Zero testes** — Plataforma financeira sem testes | ALTA | Certa | NAO MAPEADO |
| 11 | **Modelo SaaS nao validado** — Precos baseados em chutes | MEDIA | Alta | Ignorado |
| 12 | **SEO inexistente** — HashRouter + SPA = morte organica | MEDIA | Certa | Mapeado |
| 13 | **Agentes de IA como equipe** — Fantasia organizacional | MEDIA | Alta | Consciente (e defendido) |
| 14 | **Dependencia de startups** — Supabase, Woovi, Stripe, Vercel | MEDIA | Media | Parcialmente mapeado |

---

# 2. ANALISE POR DIMENSAO

## 2.1 ESTRATEGIA DE NEGOCIO & MODELO DE MONETIZACAO

### O que esta BOM
- **Diferenciais conceituais reais:** Split de pagamentos (produtor recebe em D+1) e white label completo sao frestas legitimas no mercado brasileiro.
- **Documentacao extensa:** 124+ paginas de specdrive demonstram planejamento disciplinado.
- **Decisao de adiar POS Cashless:** Reconhecimento de que o POS e um produto separado, nao core.
- **Frontend como ativo:** 66 paginas visualmente completas economizariam 6-12 meses de desenvolvimento.

### O que e FRAGIL
- **Modelo de precos 5-7%:** A margem real da Aura e "paper-thin". Em um evento de R$ 10.000, a Aura lucra R$ 400-600 brutos — insuficiente para sustentar aquisicao de clientes (CAC medio B2B Brasil: R$ 3.000-8.000).
- **Planos SaaS (R$ 149-999/mes):** Precificacao baseada em benchmarks internacionais (TicketSauce EUA) sem adaptacao ao Brasil. A Sympla nem cobra mensalidade — como convencer produtores a pagarem?
- **Analise competitiva com vies:** A Sympla tem plano Enterprise com customizacao. A Nutickets tem ZERO presenca no Brasil. O Eventbrite SAiu do Brasil em janeiro de 2026.
- **Projecoes irreconciliaveis:** R$ 8,88M/ano (D3) vs. R$ 275K/ano (D9). Receita realista no Ano 1: **R$ 80-150K**.

### O que e FANTASIA
- **500 produtores em 12 meses:** Com zero marca, zero tracao e CAC de R$ 3-8K, isso exigiria R$ 600K-1,6M em investimento de marketing que nao consta no plano.
- **TAM de R$ 250 bilhoes:** Inflado em 77%. A ABRAPE projeta R$ 141,1 bilhoes para 2025.
- **Mensagem "Na Sympla voce vende ingressos, na Aura voce gerencia seu negocio inteiro":** Wishful thinking. Produtores brasileiros (majoritariamente MEIs) querem vender ingressos, nao "gerenciar negocio".

---

## 2.2 TECNOLOGIA & ARQUITETURA

### O que esta BOM
- **Stack moderna e produtiva:** React 19 + TypeScript + Vite + Tailwind + Supabase e uma escolha sensata para MVP.
- **Schema cobre dominios:** As 30 tabelas enderecam todos os dominios do problema (eventos, ingressos, pagamentos, CRM, certificados).
- **Arquitetura de pagamentos gateway-agnostic:** Tecnicamente elegante, permite troca de gateway sem refatorar UI.
- **Componentes shadcn/ui:** 62 componentes acessiveis reduzem trabalho de UI.

### O que e FRAGIL
- **Inconsistencia fatal no schema:** Tabela `producer_profiles` mencionada em D11 mas AUSENTE em D5. Sem ela, nao ha KYC nem split. A tabela `users` (D5) vs. `profiles` (D8) — qual e a verdadeira?
- **ON DELETE CASCADE perigoso:** Deletar um evento apaga todos os tipos de ingresso permanentemente. Sem soft delete em nenhuma tabela.
- **Materialized View quebrada:** `event_summary` usa `REFRESH CONCURRENTLY` sem index UNIQUE — vai falhar.
- **RLS com vulnerabilidades:** `ticket_types` policy com `OR` sem parenteses permite leak. Tabelas `check_ins` e `communications` com RLS ativado mas zero policies.
- **Estimativas irreais:** "4 semanas para P0" = realidade: 9-13 semanas. "$46/mes" = realidade: $120-500/mes.

### O que e FANTASIA / PERIGOSO
- **Edge Function `stripe-webhook` com race condition:** Loop N+1 gera tickets. Webhook duplicado (retries do Stripe) = tickets duplicados. 14 chamadas de rede sequenciais sem transacao atomica.
- **Woovi-webhook sem validacao de assinatura:** Qualquer um pode forjar pagamentos e gerar tickets gratis.
- **Recomendacao `(select auth.uid())`:** Tecnicamente incorreta. A funcao `auth.uid()` ja e STABLE — avalia uma vez por query. O `select` adiciona overhead desnecessario. As "skills" estao treinando agentes com informacao errada.
- **"5.5 horas para infraestrutura pronta":** Realidade: 1-2 semanas so para configuracoes basicas funcionais.

---

## 2.3 PRODUTO & FRONTEND

### O que esta BOM
- **Seating Map (Canvas HTML5):** Diferencial tecnico real. Nenhum concorrente brasileiro tem.
- **Certificate Builder (12 templates):** Outro diferencial funcional.
- **Estrutura de diretorios razoavel:** Separacao por modulos, layouts diferenciados, roteamento organizado.

### O que e FRAGIL
- **A "Ilusao do 95% Pronto":** Apenas 2 features funcionam (Seating Map, Certificate Builder). 60 paginas sao maquete. O frontend esta mais para 5% pronto do que 95%.
- **2 hooks para 66 paginas:** Estrutura incompleta. Logica de negocio espalhada em componentes.
- **1 contexto para 5 modulos:** Estado misturado, sem cache inteligente.
- **Dados mock monoliticos:** Substituir por APIs nao sera plug-and-play — shapes inconsistentes com schema real.
- **Header nao responsivo, sidebar nao colapsa:** Amadorismo em 2025.

### O que e FANTASIA
- **Estimativa D2: "4 semanas para P0":** Realidade: 14-22 semanas com 2 devs.
- **"Checkout Stripe: 3 dias":** Realidade: 3-4 semanas considerando edge cases, testes, conciliacao.
- **20 componentes de pagamento gateway-agnostic:** Overengineering para produto sem transacoes. YAGNI violado.
- **"5 semanas para substituir todos os mocks":** Impossivel. 60 paginas x integracao media de 2-3 dias = 24-36 semanas.

---

## 2.4 RISCOS, COMPLIANCE & OPERACAO

### O que esta BOM
- **D9 reconhece riscos legitimos:** Ilusao do 95% pronto, POS Cashless como calcanhar de Aquiles, dependencia de gateway.
- **Mitigacoes razoaveis:** KYC rigoroso, limites progressivos, multi-gateway, auditoria manual de RLS.
- **Decisao de adiar POS Cashless:** Sapiencia estrategica.

### O que e FRAGIL
- **Riscos mapeados sao os "faceis":** Todos os documentos focam em riscos tecnicos e de mercado, ignorando os juridicos e operacionais.
- **KYC rudimentar:** Sem gateway definido, o KYC nao pode ser implementado. A Stripe exige CNPJ — e muitos produtores sao PF.
- **"Equipe" de 12 agentes de IA:** E 1 pessoa dando prompts. Workflow de 11 fases e burocracia ilusoria.
- **Sem plano de suporte:** Ninguem resolve problema as 21h de sabado quando o QR code nao funciona na porta do evento.

### O que e GRAVE / NAO MAPEADO
- **Crime de intermediacao financeira ilegal (Lei 7.492/1986):** A atividade de split automatico configura prestacao de servico de liquidacao — exclusiva de instituicoes autorizadas pelo BACEN.
- **LGPD nao implementada:** Sem DPO, ROPA, DPIA, Termos de Uso, Politica de Privacidade. Multas ate R$ 50 milhoes.
- **PLD/FT ausente:** Nenhuma mencao a prevencao a lavagem de dinheiro — obrigatorio para operadores de pagamento.
- **Nota fiscal e tributacao do split:** Nenhuma mencao. Como a Aura emite NF sobre a taxa? Como o produtor declara? Como funciona a retencao de ISS/ICMS/PIS/COFINS?
- **Single point of failure humano:** 1 pessoa. Doenca, acidente ou desistencia = fim do projeto.
- **Sem runway, sem burn rate, sem fonte de financiamento:** O projeto e bootstrapped? Ha investidor? Ninguem sabe.

---

# 3. RECOMENDACOES ESTRATEGICAS PRIORIZADAS

## ACES IMEDIATAS (Semana 1 — antes de qualquer codigo)

1. **Consultoria juridica em direito bancario:** Avaliar se a atividade configura Instituicao de Pagamentos. Se sim, iniciar processo de autorizacao junto ao BACEN (6-12 meses, R$ 1-2M de capital). Se nao, redefinir modelo para "mero prestador de tecnologia" (sem split automatico).

2. **Consultoria LGPD:** Nomear DPO, criar ROPA, DPIA, Termos de Uso e Politica de Privacidade.

3. **Definir gateway de pagamento:** Nao e algo para "decidir depois". E a fundacao do negocio. Recomendacao: contratar Pagar.me (Stone) — presenca nacional, suporte local, menos risco de bloqueio que Stripe.

4. **Criar estrutura juridica:** CNPJ da empresa, contrato social compativel, seguro de responsabilidade civil.

## ACES DE ALTA PRIORIDADE (Mes 1)

5. **Revisar schema do banco:** Adicionar `producer_profiles`, soft deletes, indexes compostos, corrigir CASCADE para RESTRICT.

6. **Reescrever Edge Functions:** Adicionar idempotencia (stripe-webhook), validacao de assinatura (woovi-webhook), transacoes atomicas.

7. **Implementar testes:** Testes unitarios para Edge Functions, testes de integracao para fluxo de pagamento, testes de RLS (simular usuario malicioso).

8. **Revisar projecoes financeiras:** Basear em dados reais de mercado. Meta realista Ano 1: R$ 80-150K de receita, 20-50 produtores ativos.

## ACES DE MEDIA PRIORIDADE (Mes 2-3)

9. **Trocar HashRouter por Next.js:** SEO e essencial para plataforma de eventos. SPA com HashRouter e morte do trafego organico.

10. **Implementar Zustand + TanStack Query:** Substituir mock data por integracao real, pagina por pagina, com loading states e error handling.

11. **Criar plano de suporte:** WhatsApp Business, FAQ, documentacao para produtores. Alguem precisa atender quando der problema.

12. **Contratar equipe:** Minimo 1 dev senior backend + 1 dev frontend + 1 pessoa de operacao/suporte. Agentes de IA sao copilotos, nao substitutos.

---

# 4. CENARIOS PROVAVEIS

### Cenario A: Falencia em 12 meses (60% de probabilidade)
- Projeto lanca com MVP fragil, sem gateway definido
- BACEN questiona atividade ou Stripe bloqueia conta
- Sem equipe de suporte, produtores abandonam apos primeiro problema
- Receita: R$ 0-30K. Projeto encerrado.

### Cenario B: Pivot para micro-SaaS sustentavel (30% de probabilidade)
- Abandona split automatico, opera como "prestador de tecnologia"
- Foco em nicho (casas de show pequenas, festivais independentes)
- Receita Ano 1: R$ 80-200K. Crescimento lento mas sustentavel.

### Cenario C: Escala de sucesso (10% de probabilidade)
- Consegue autorizacao BACEN ou parceria com instituicao de pagamento
- Levanta rodada de investimento (R$ 2-5M)
- Contrata equipe completa (engenharia + operacao + comercial)
- Receita Ano 3: R$ 1-3M. Nunca R$ 8,88M/ano.

---

# 5. CONCLUSAO

O projeto Aura e um estudo de caso classico de **otimismo seletivo embalado em planilhas bonitas e documentacao extensa**. Seus 14 documentos transbordam confianca tecnica — "66 paginas prontas", "exercito de 12 agentes", "specdrive de 158 paginas" — mas escondem uma realidade mais prosaica: **zero transacoes processadas, zero tabelas criadas, zero testes escritos, e uma divida regulatoria que pode inviabilizar o projeto antes mesmo do primeiro evento.**

O que o Aura precisa nao e mais documentacao, nao e mais agentes de IA, e nao e mais features. **O que o Aura precisa e honestidade brutal sobre onde realmente esta, coragem para cortar o escopo ao minimo viavel, e dinheiro suficiente para contratar uma equipe real.**

Os documentos dizem: "A questao nao e 'o que construir?' — e 'em que ordem construir para maximizar receita o mais rapido possivel?'"

A verdade e: **a questao e 'sera que podemos construir algo legal antes de sermos multados, processados ou superados pela realidade?'**

---

*Analise produzida por 4 agentes especializados em paralelo: Estrategia de Negocio, Tecnologia & Arquitetura, Produto & Frontend, Riscos & Operacao.*
*Documentos-base: Aura_Plano_Estrategico_Ecossistema, Aura_Relatorio_Completo_Produto_Competitividade, D1 a D12.*
