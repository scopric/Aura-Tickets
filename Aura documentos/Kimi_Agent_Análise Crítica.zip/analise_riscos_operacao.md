# ANALISE CRITICA DE RISCOS, COMPLIANCE, OPERACAO E VIABILIDADE ORGANIZACIONAL
## Projeto Aura — Plataforma SaaS de Gestao de Eventos com Processamento de Pagamentos

**Analista:** Especialista em Gestao de Riscos Tecnologicos e Compliance Financeiro  
**Data:** Maio de 2025  
**Documentos Analisados:** D5 (Supabase Spec), D6 (Arquitetura), D7 (Organizacao Agentes), D9 (Riscos Estrategicos), D12 (Manual Operacoes Agente), Plano Estrategico do Ecossistema

---

## RESUMO EXECUTIVO

Apos analise exaustiva dos 6 documentos do projeto Aura, emito o seguinte veredito: **o projeto possui uma arquitetura tecnica razoavelmente documentada, mas opera sob uma camada de ingenuidade juridica, organizacional e operacional que o torna extremamente vulneravel a falencia, sancoes regulatorias e catastrofes reputacionais.** Os documentos transbordam confianca tecnica ("66 paginas prontas", "exercito de 12 agentes", "specdrive de 124 paginas") mas demonstram ignorancia alarmante sobre regulamentacao financeira, governanca corporativa e operacao real de plataformas de pagamentos.

**Esta analise identifica riscos que NENHUM dos documentos mencionou — incluindo a possibilidade de o projeto ser considerado ilegal pelo Banco Central antes mesmo de processar sua primeira transacao.**

---

## 1. REGULAMENTACAO E COMPLIANCE FINANCEIRO: A BOMBA-RELÓGIO

### 1.1 Aura Pode Ser uma Instituição de Pagamentos Ilegal

Os documentos descrevem um modelo em que a Aura: (a) processa pagamentos de compradores de ingressos, (b) controla o fluxo de pagamentos (Plano Estrategico, secao 3.4: "Controlar o fluxo de pagamentos para ganhar com taxas"), (c) executa split automatico de receita entre produtor, plataforma e gateway via Edge Functions (D5, `stripe-webhook`), (d) intermedeia pagamentos entre compradores e produtores, e (e) define KYC e limites progressivos (D9).

**Esta atividade configura prestacao de servico de "conta de pagamento" e/ou "instituicao de pagamento" segundo a Circular nº 3.885/2018 do Banco Central do Brasil.** A Circular estabelece que toda entidade que mantenha contas de pagamento para clientes, facilite pagamentos entre partes ou execute transferencias de fundos em nome de terceiros DEVE ser uma Instituição de Pagamento (IP) autorizada pelo BACEN. Operar sem autorizacao constitui crime de exercicio ilegal de intermediacao financeira (Lei 7.492/1986, art. 7º), punivel com reclusao de 2 a 6 anos.

### 1.2 A Ilusao do "Gateway Faz Tudo"

Os documentos repetem a crenca de que, como Stripe e Woovi "fazem o processamento", a Aura nao precisa se preocupar com regulamentacao. **Isso e um erro juridico grave.** A Aura nao esta simplesmente "indicando" o gateway — ela define regras de split (R$ 93/5/2), controla liberacao de valores (D+1 Pix, D+30 cartao), faz KYC dos produtores e monitora chargeback. **Sao atividades de intermediacao financeira — nao de uma SaaS de eventos.**

### 1.3 Split de Pagamento: A Linha Vermelha

O split automatico (D5, Edge Function `stripe-webhook`) e a funcionalidade mais perigosa regulatoriamente. Quando uma plataforma **recebe dinheiro de um comprador e redistribui para multiplas partes**, ela executa funcao de liquidacao — atividade exclusiva de instituicoes autorizadas pelo BACEN. A Lei 14.259/2021 regulamenta operacoes de escrow e retencao de valores entre partes, exigindo estrutura societaria e patrimonial especifica.

### 1.4 Consequencias e o Que Falta

Riscos concretos: interdicao da atividade pelo BACEN (multa ate 1% do faturamento), bloqueio preventivo de contas bancarias da empresa, responsabilidade criminal dos socios/administradores, e responsabilidade civil solidaria por valores nao repassados a produtores.

**NENHUM dos 6 documentos menciona consultoria juridica em direito bancario, autorizacao junto ao BACEN, ou estrutura societaria compativel.** A mencao generica "compliance: PCI DSS, LGPD, KYC" (Plano Estrategico, secao 6) nao substitui analise regulatoria especifica. A estrutura juridica pode levar 6-12 meses para aprovacao e exigir capital social minimo de R$ 1-2 milhoes. A alternativa e operar como mero prestador de tecnologia, onde o gateway e o unico responsavel — mas isso elimina o split automatico, o diferencial competitivo declarado.

---

## 2. LGPD: MENCAO DECORATIVA SEM EXECUCAO

A LGPD e mencionada **exatamente uma vez** em todo o conjunto documental ("compliance: PCI DSS, LGPD, KYC"). Nao ha: DPO nomeado (obrigatorio por lei para operadores de dados financeiros), ROPA (Registro de Atividades de Tratamento), DPIA para dados financeiros, Termos de Uso, Politica de Privacidade, matriz de consentimentos, plano de resposta a incidentes, ou DPA (Data Processing Addendum) com processadores de dados.

O schema do Supabase (D5) coleta CPF (`users.cpf`), telefone, dados bancarios dos produtores, localizacao geografica (`events.venue_lat`, `venue_lng`) e historico de compras — **todos dados pessoais sensiveis sob a LGPD (art. 5º, II)**, exigindo base legal especifica, medidas de seguranca reforcadas e DPIA obrigatorio.

A arquitetura utiliza seis provedores internacionais (Supabase/EUA, Stripe/EUA, Vercel/EUA, Resend/EUA, Google/Antigravity/EUA, Hostinger/Holanda), significando **transferencia internacional de dados de todos os usuarios brasileiros** sem qualquer mencao ao art. 33 da LGPD, que exige salvaguardas especificas (pais com nivel adequado de protecao, clausulas contratuais tipo, etc.).

Multas da ANPD chegam a **2% do faturamento, limitadas a R$ 50 milhoes por infracao.** Em caso de vazamento de dados de pagamento, a responsabilidade civil e ilimitada e solidaria.

---

## 3. CHARGEBACK E FRAUDE: ILUSAO DE CONTROLE

D9 menciona "monitoramento de chargeback >0,5%", mas: (a) sem gateway definido, nao ha como implementar monitoramento real; (b) sem conta Stripe criada, nao ha historico de risco; (c) a Stripe bloqueia contas novas com perfil de evento (considerado "high risk" pelo setor de entretenimento ao vivo) sem aviso previo, retendo fundos por 90-180 dias.

O KYC proposto ("verificacao de identidade e comprovante de residencia") e rudimentar. A Stripe Connect para contas brasileiras exige CNPJ do produtor — que muitos eventos de pequeno porte nao possuem. **Sem CNPJ, nao ha conta Connect. Sem conta Connect, nao ha split.** O projeto nao tem um plano para eventos feitos por pessoa fisica, que representam uma fatia significativa do mercado brasileiro de eventos.

Se a conta da Aura for bloqueada, **todos os produtores param de receber simultaneamente.** Nao ha mencao a conta reserva (reserve fund) ou segregacao de recursos por produtor. A recomendacao de "multi-gateway" (D9) e teoricamente valida, mas na pratica significa manter integracoes, contratos e saldos em multiplos provedores — complexidade operacional que uma equipe de uma pessoa nao consegue sustentar.

---

## 4. MODELO DE AGENTES DE IA: FANTASIA QUE MASCARA VULNERABILIDADE

D7 propoe 3 agentes por funcao; D12 expande para 12 agentes em 6 times com "comandos militares" ("MAESTRO INICIAR", "RADAR SCAN", "AUDITOR SEC"). Esta linguagem mistica **oculta a ausencia total de estrutura organizacional real.**

### Por que isso nao funciona na pratica:

1. **Nao existem 12 agentes.** Existe UMA pessoa operando uma IDE com IA e dando prompts sequenciais. Os "12 agentes" sao modos de prompt, nao entidades autonomas. A pessoa precisa ter expertise para: formular o prompt, avaliar o codigo, debugar quando falhar, e decidir quando ignorar a IA.

2. **O workflow de 11 fases (D12) e burocracia ilusoria.** Com uma unica pessoa, o processo e: escrever prompt → copiar codigo → testar manualmente → commit. A metafora militar adiciona complexidade sem capacidade real.

3. **"Um arquivo, um agente por vez" (D12, R2) e impossivel.** Uma pessoa nao simula 12 agentes paralelos com exclusao mutua. E sequencial por natureza.

4. **Um prompt "AUDITOR SEC" nao substitui um auditor humano.** Ha casos documentados de IA gerando codigo com vulnerabilidades de SQL injection e XSS que passaram "na auditoria" do proprio modelo. Codigo financeiro exige olhos humanos experientes.

5. **O specdrive completo (124 paginas) excede a janela de contexto dos modelos de IA** (tipicamente 128-200K tokens), tornando impossivel o "conhecimento total" que os documentos prometem.

### A Verdade Organizacional

A realidade que os documentos escondem com metaforas militares: **existe uma (ou duas) pessoa(s) operando o projeto, sem equipe tecnica, sem CTO, sem lideranca de engenharia, e sem experiencia previa em plataformas de pagamentos.** Os "12 agentes" sao fantasia organizacional que mascara vulnerabilidade estrutural extrema.

---

## 5. RISCOS NAO MAPEADOS: O QUE NINGUEM PERCEBEU

Alem dos riscos ja identificados em D9 (Ilusao do 95% Pronto, POS Cashless, Dependencia de Gateway, Seguranca Supabase, Concorrencia e Preco), os seguintes riscos criticos **nao foram mencionados em nenhum documento:**

### 5.1 Risco Reputacional Catastrofico
Se um evento de grande porte usar a Aura e o check-in falhar na porta, a noticia viraliza nas redes sociais em minutos. Produtores de eventos formam uma comunidade fechada onde recomendacoes (positivas ou negativas) se propagam rapidamente. **Uma unica falha visivel pode destruir a reputacao da plataforma permanentemente.** Nao ha plano de comunicacao de crise, spokesperson, nem equipe de relacoes publicas.

### 5.2 Nao-Conformidade Tributaria
O split de pagamento entre produtor, plataforma e gateway gera obrigacoes tributarias complexas: a Aura deve emitir nota fiscal pela taxa de servico (5-7%), transacoes intermunicipais tem regras de ISS/ICMS diferentes, e pode haver responsabilidade como substituta tributaria. **Nenhum documento menciona emissao de NF ou obrigacoes tributarias do split.**

### 5.3 Lavagem de Dinheiro (PLD/FT)
Uma plataforma que processa pagamentos para eventos e **vetor natural para lavagem de dinheiro.** Um criminoso pode criar eventos ficticios, comprar ingressos com dinheiro ilicito e receber o split do produtor como dinheiro "limpo." Os documentos nao mencionam Programa de Prevencao a Lavagem de Dinheiro (PLD/FT), obrigatorio para instituicoes que operam com valores significativos. A ausencia e particularmente preocupante dado o limite de R$ 100 mil em vendas para eventos "altos" — valor suficiente para atrair atencao de orgaos de inteligencia financeira.

### 5.4 Escassez de Capacidade Tecnica
O projeto depende de UMA pessoa no Antigravity. Se essa pessoa ficar doente, desistir, ou ter um acidente, **nao ha substituto.** O conhecimento tacito (senhas, configuracoes, decisoes arquiteturais) esta apenas na cabeca dessa pessoa e em prompts de IA nao-persistentes. Nao ha documentacao de runbooks, senhas de emergencia, ou plano de sucessoria.

### 5.5 Concentracao de Risco em Edge Functions
Todas as transacoes financeiras passam por Edge Functions no Supabase que acessam a `service_role_key`. Se comprometida (vazamento no repositorio GitHub publico, phishing, engenharia social), um atacante pode **ler e modificar todas as transacoes financeiras da plataforma.** D5 menciona "Nunca exponha essa chave no frontend" mas nao protecao contra outros vetores de vazamento.

---

## 6. OPERACAO NO DIA DO EVENTO: O VAZIO MAIS ASSUSTADOR

Quando ha 500 pessoas na porta de uma casa de show e o QR code nao funciona — **quem resolve?**

Os documentos descrevem elegantemente a tecnologia (html5-qrcode, Edge Function `checkin-scan`, Supabase Realtime), mas **nao ha um unico paragrafo sobre operacao humana no dia do evento.** Nao existe: equipe de suporte, plantao tecnico 24/7, tecnico de campo, canal de emergencia para produtores, ou plano de contingencia operacional (lista impressa de participantes? check-in manual? reembolso imediato?).

O D6 menciona Crisp/Intercom como "futuro." D9 menciona "suporte por WhatsApp" sem dizer quem atende. **Eventos acontecem predominantemente sexta-domingo, a noite. Se o sistema cai as 22h de sabado, ninguem acorda para resolver.**

**Cenario do desastre:** evento com 2.000 pessoas, sistema fora do ar as 21h, filas crescendo, participantes postando stories com hashtag do evento. Em 30 minutos, caos generalizado. Em 2 horas, o produtor jura nunca mais usar a Aura. Na segunda-feira, o Reclame Aqui esta cheio. Na semana seguinte, nenhum produtor responde ao cold call. Isso nao e paranoia — e probabilidade estatistica de picos de trafego extremos (0 a 2.000 requests/minuto na abertura das portas) sem teste de carga, sem CDN otimizada para QR code, e sem equipe de plantao.

---

## 7. SINGLE POINTS OF FAILURE

| Ponto de Falha | Impacto | Mitigacao Documentada |
|---|---|---|
| 1 desenvolvedor/operador | Projeto para se a pessoa sumir | **Nenhuma** |
| 1 conta Supabase | Todo o backend para | **Nenhuma** |
| 1 conta Stripe Connect | Todos os pagamentos cartao param | "Multi-gateway" (nao implementado) |
| 1 conta Woovi | Todos os pagamentos Pix param | **Nenhuma** |
| 1 dominio (aura.events) | Plataforma inacessivel | **Nenhuma** |
| Gateway nao definido | Impossivel processar pagamentos | "Decidir na Fase 2, Semana 9" |
| Sem testes de carga | Falha em eventos com alto trafego | **Nenhuma** |
| Sem testes de disaster recovery | Sem plano de recuperacao | **Nenhuma** |
| Sem backup de banco documentado | Perda total de dados em catastrofe | **Nenhuma** |

---

## 8. DEPENDENCIA DE TERCEIROS

- **Supabase (MEDIO-ALTO):** Startup de 4 anos, serie B (~US$ 116M). Dependencia total (banco, auth, storage, realtime, edge functions) cria vendor lock-in extremo. Migracao levaria 3-6 meses. Ja teve incidentes de indisponibilidade documentados.
- **Stripe (ALTO):** Conhecida por bloquear contas sem aviso previo. Plataformas de eventos sao "high risk." A conta Connect pode ser suspensa no primeiro evento com disputas. Processo de desbloqueio e opaco.
- **Woovi/OpenPix (ALTO):** Startup brasileira pequena. Se mudar de API, aumentar precos, ou fechar operacao, a integracao de Pix para. O proprio Plano Estrategico ja lista PicPay e Mercado Pago como alternativas — reconhecimento implicito de fragilidade.
- **Antigravity/Google (MEDIO):** Produto em beta, gratuito. Todo o "exercito de agentes" desaparece se o produto mudar, for descontinuado, ou tiver degradacao de qualidade.
- **Vercel (BAIXO-MEDIO):** Empresa estabelecida, mas o plano Pro a US$ 20/mes nao inclui suporte dedicado. Em incidente critico, dependencia de suporte comunitario.

---

## 9. CULTURA E GOVERNANCA: A AUSENCIA E O PROBLEMA

**Nao ha CTO. Nao ha CEO mencionado. Nao ha equipe. Nao ha comite de riscos. Nao ha conselho consultivo.**

Os documentos descrevem uma estrutura onde **"Voce"** (D12: "ANTIPODIO GERAL (Voce) — Define estrategia, aprova, toma decisoes") e o **"Maestro"** (agente de IA) coordenam. Literalmente: **uma unica pessoa toma todas as decisoes estrategicas e operacionais**, e quando indisponivel, delega a prompts de IA. Isso nao e governance agil — e ausencia de governanca.

Nao ha: revisao de arquitetura antes de ir para producao, aprovacao de mudancas em codigo financeiro, comite de liberacao de releases, processo de post-mortem para incidentes, ou avaliacao de impacto regulatorio antes de lancar funcionalidades.

**Delegar decisoes tecnicas de arquitetura a um modelo de linguagem probabilistico (que "adivinha" a proxima palavra mais provavel) e irresponsavel quando dinheiro real de clientes esta em jogo.**

---

## 10. PLANO DE CONTINGENCIA: A INEXISTENCIA

Os documentos nao quantificam: investimento feito ate o momento, runway disponivel, burn rate mensal, fonte de financiamento (bootstrapped? investidor anjo? Nao consta), ou prejuizo total em caso de falencia. A projecao financeira (D9) assume receita de R$ 275 mil no primeiro ano, mas nao menciona custos operacionais reais, salarios (se houver), ou custos juridicos/regulatorios que serao inevitaveis.

**Nao ha plano de desligamento:** se a empresa precisar fechar, como serao tratados pagamentos pendentes a produtores, ingressos vendidos para eventos futuros, e dados pessoais dos usuarios (LGPD exige delecao ou anonimizacao)?

---

## RECOMENDACOES ESTRATEGICAS IMEDIATAS

### CRITICAS (Antes de qualquer codigo adicional):

1. **Consultoria juridica em direito bancario** — Avaliar se a atividade exige autorizacao BACEN. Orcamento: R$ 15-30 mil. Prazo: 30 dias. **Esta e a decisao que pode determinar se o projeto e viavel ou ilegal.**
2. **Nomear DPO e iniciar compliance LGPD** — Criar termos de uso, politica de privacidade, ROPA, e DPA com todos os processadores de dados. Orcamento: R$ 10-20 mil.
3. **Definir gateway AGORA** — A decisao de "esperar a Fase 2" e inaceitavel para uma plataforma cujo core business e processamento de pagamentos. Criar contas em Stripe, Woovi e PagSeguro e executar transacoes de teste.
4. **Plano de operacao 24/7** — Definir quem atende o telefone quando o sistema cai. Contratar suporte terceirizado ou estabelecer plantao minimo.
5. **Teste de carga obrigatorio** — Simular 2.000 check-ins simultaneos antes de qualquer evento real. Identificar gargalos antes que clientes identifiquem.

### ALTA PRIORIDADE (Primeiros 60 dias):

6. **Estruturar empresa adequadamente** — Definir socios, capital social compativel com regulamentacao, e estrutura societaria formal.
7. **Contratar pelo menos 1 dev senior** — Substituir a metafora dos "12 agentes" por equipe minima real com expertise em pagamentos.
8. **Implementar monitoramento e alertas** — Sentry, UptimeRobot, e alertas de volume de transacoes anomalas.
9. **Criar plano de contingencia documentado** — O que fazer quando (nao "se") cada sistema falhar.
10. **Adiar indefinidamente o POS Cashless** — D9 ja recomendou; reforco: hardware em evento ao vivo e produto separado que exige equipe propria, logistica fisica e testes extensivos.

---

## CONCLUSAO

O Aura tem **visao de produto clara** e **arquitetura tecnica coerente.** O split de pagamentos e o white label sao diferenciais reais no mercado brasileiro de eventos. Contudo, **a execucao esta fundamentada sobre pressupostos perigosos:** que IA substitui equipe tecnica, que processamento de pagamentos nao exige regulamentacao, que 66 paginas de frontend mockado significam que o projeto esta "85% pronto", e que uma unica pessoa operando prompts em uma IDE pode construir uma plataforma de pagamentos segura e regulamentada.

**A verdade incômoda e que o Aura esta mais proximo de um conceito de produto bem-documentado do que de uma empresa operacional.** A distancia entre "specdrive de 124 paginas" e "plataforma processando transacoes reais de clientes reais" e medida em anos, nao em semanas — e inclui obstaculos que nenhum documento identificou: o Banco Central, a ANPD, a Receita Federal, e a realidade implacavel de operar um sistema que nao pode falhar as 21h de um sabado.

**A decisao mais importante que os fundadores podem tomar agora nao e qual gateway escolher — e se a estrutura juridica e organizacional que precisam construir vale o esforco necessario para transformar este conceito em uma empresa legitima, regulamentada e sustentavel.**

---

*Analise produzida para fins estrategicos internos. Observacoes sobre regulamentacao nao constituem parecer juridico e devem ser validadas por advogado especializado em direito bancario.*
