# ANALISE ESTRATEGICA CRITICA: PROJETO AURA
## Plataforma SaaS de Gestao de Eventos (Ticketing)
### Analise de um Analista Estrategico Senior | Junho 2025

---

## RESUMO EXECUTIVO

O projeto Aura apresenta um **diagnostico estrategico com acertos pontuais e uma visao de produto ambiciosa**, mas suas projecoes financeiras oscilam entre o otimismo ingenuo e a fantasia pura. O gap de **32x entre a projecao otimista (R$ 8,88M/ano) e a conservadora (R$ 275K/ano)** revela uma equipe que nao tem certeza do proprio modelo de negocio. O frontend de 66 paginas com 82+ componentes e um ativo real, mas o fato de que **90% operam com mock data, nenhuma tabela de banco foi criada e nenhum gateway de pagamento foi definido** aponta para um projeto que esta, na melhor das hipoteses, **15-20% do caminho para um MVP funcional**.

A proposta de competir com a Sympla (350.000 produtores, 62.000 eventos simultaneos, 190 mil ingressos/dia) com taxas 30-50% menores ignora a dinamica fundamental do mercado B2B de eventos: **produtores pagam mais por confiabilidade, nao por funcionalidades.** A mensagem "Na Sympla voce vende ingressos. Na Aura voce gerencia seu negocio inteiro" soa como *wishful thinking* de uma startup que nunca processou uma venda real.

**Veredicto geral: O Aura tem diferenciais conceituais reais (white label, split de pagamentos), mas seu plano financeiro e irreconciliavelmente otimista, sua analise competitiva contem vieses graves de confirmacao, e sua estrategia go-to-market subestima brutalmente a dificuldade de roubar clientes de um monopolio estabelecido.**

---

## 1. MODELO DE PRECOS E TAXAS: A ILUSAO DOS 5-7%

A proposta de taxa de servico de 5-7% (vs. 10-12% da Sympla) parece vantajosa a primeira vista, mas desmorona sob analise.

**O que esta errado:**

**1.1. Margem real da Aura e paper-thin.** Se a Aura cobra 5% do produtor e repassa 0,99% para a Woovi (Pix) ou 2,9% para a Stripe (cartao), sobram **R$ 0,04 por real transacionado via cartao** (5% - 2,9% = 2,1%) ou **R$ 2,11 por ingresso de R$ 100 via Pix** (R$ 5,00 - R$ 0,99 = R$ 4,01, menos custos operacionais). Num evento de R$ 10.000, a Aura lucra R$ 400-600 brutos. Isso nao sustenta uma operacao com CAC medio de R$ 3.000-8.000 (benchmark SaaS B2B Brasil).

**1.2. A Sympla ja absorve a concorrencia de preco.** O documento omite que a Sympla tem plano Enterprise com taxas negociaveis e que a taxa de 12% e o *teto*, nao o padrao. Produtores grandes ja pagam menos que 10%. A vantagem de preco da Aura e menor do que parece.

**1.3. O custo de processamento da Aura e MAIOR que o da Sympla em alguns cenarios.** A Aura propoe 2,9% + R$0,30 via Stripe para cartoes. A Sympla cobra 2-2,5% sem tarifa fixa. Em ingressos de R$ 30-50, a Aura sera MAIS CARA no processamento — o exato segmento de maior volume no Brasil.

**1.4. A taxa Woovi de 0,99% e real, mas limitada.** A Woovi so processa Pix. Nao aceita cartao de credito. Isso significa que a Aura precisara de multiplos gateways, aumentando complexidade tecnica e custo de manutencao. E a promessa de split "automatico" via Stripe Connect no Brasil envolve burocracia regulatoria (registro de arranjos de pagamento, compliance Banco Central) que o documento ignora por completo.

**Veredicto:** O modelo de precos e viavel operacionalmente, mas **nao gera margem suficiente para sustentar aquisicao de clientes em escala.** A Aura precisaria de volume monstruoso (R$ 50M+/ano em GMV) para cobrir custos operacionais com essas taxas — e isso pressupoe que a Sympla nao reaja, o que e impossivel.

---

## 2. PROJECOES FINANCEIRAS: ENTRE A FANTASIA E A REALIDADE

O gap de **32x entre as projecoes** (R$ 8,88M no D3 vs. R$ 275K no D9) e o sinal de alerta mais gritante deste plano de negocio.

### Analise da Projecao Otimista (D3 - R$ 8,88M/ano)

A projecao assume que em 12 meses a Aura tera:
- 500 produtores ativos
- R$ 3M em GMV mensal
- R$ 120K de MRR (Receita Recorrente Mensal)
- 300 eventos/mes criados
- Taxa de conversao de 5%

**Por que isso e impossivel:**

**2.1. Cenario realista de penetracao de mercado.** Com CAC medio de R$ 5.000 (benchmark B2B SaaS Brasil) e ticket medio de R$ 149-399/mes, o payback por cliente SaaS seria de **12-33 meses** — se nao houver churn. A projecao assume 200 assinantes pagantes em 6 meses sem nenhum investimento em marketing documentado. Com zero marca, zero case studies e zero tracao, aquisicionar 200 clientes B2B em 6 meses exigiria R$ 600K-1,6M em investimento de marketing/vendas — que nao consta no plano.

**2.2. O ARR de R$ 4,68M no mes 12** pressupoe que cada produtor gera R$ 936/mes em media. Mas o plano SaaS maximo e R$ 999/mes e a maioria dos produtores de eventos no Brasil sao **microempreendedores individuais que fazem 1-2 festas por mes.** Eles nao pagarao R$ 999/mes. O plano Gratis sera o mais usado — o classico "freemium death spiral."

**2.3. A taxa de churn projetada (<5% ao mes)** e metade da media SaaS B2B no Brasil (8-12%/mes para startups sem tracao). Com um produto nao testado em producao, churn de 15-20% nos primeiros meses e mais realistico.

### Analise da Projecao Conservadora (D9 - R$ 275K/ano)

Esta projecao assume:
- 140 eventos em 12 meses (comecando gratis)
- R$ 5,55M em GMV total
- Receita de apenas 5% sobre GMV

**Esta e a unica projecao remotamente realista**, mas ainda e otimista. Ela pressupoe que a Aura conseguira convencer 140 produtores a usarem uma plataforma sem tracao, sem marca, sem suporte comprovado — em vez de usar a Sympla gratuitamente.

### A Verdadeira Projecao

Com base nos dados de mercado, uma projecao REALISTICA seria:
- **Ano 1: R$ 80K-150K em receita** (20-40 produtores ativos, 80% no plano Gratis)
- **Ano 2: R$ 300K-600K** (se o produto provar estabilidade)
- **Break-even: Mes 18-24** (na melhor das hipoteses)

**A projecao de R$ 8,88M e pura fantasia. A de R$ 275K e dificil mas possivel.**

---

## 3. ANALISE COMPETITIVA: VIES DE CONFIRMACAO E FATOS IGNORADOS

A analise competitiva do Aura contem erros graves que revelam vies de confirmacao.

### 3.1. A Sympla "nao oferece white label" — VERDADE PARCIAL

O documento afirma categoricamente que a Sympla nao oferece white label. Isso e **tecnicamente verdade para o publico geral**, mas a Sympla tem plano Enterprise com "solucao customizada" que inclui dominio proprio e branding personalizado para grandes produtores. O Aura esta competindo pela extremidade inferior do mercado enterprise, nao por um green field.

### 3.2. A Nutickets como benchmark — ENGANO ESTRATEGICO

A Nutickets e citada repetidamente como "referencia mundial" e "modelo a seguir." **Problema: a Nutickets NAO TEM operacao no Brasil.** Usar uma plataforma europeia sem presenca local como benchmark para precificacao e posicionamento e comparar macas com laranjas. O mercado brasileiro tem regulacao de pagamentos diferente (Pix e exclusivo do Brasil), comportamento do consumidor diferente e dinamica de custos diferente.

### 3.3. A Eventbrite como concorrente — DESATUALIZADO

O documento lista a Eventbrite como concorrente ativo. **Em janeiro de 2026, a Eventbrite ENCERROU suas operacoes no Brasil**, citando "instabilidade regulatoria." Isso deveria ser uma licao para a Aura: se uma gigante global com US$500M de valuation nao conseguiu operar no Brasil, **a barreira regulatoria e maior do que o documento reconhece.**

### 3.4. Concorrentes reais ignorados**

O documento ignora completamente concorrentes brasileiros reais que competem no mesmo espaco: Lets.Events (ticketing + gestao), Blu (cashless), EventMe, e varios outros. O mercado NAO e um vazio esperando ser preenchido.

### 3.5. A mensagem "Na Sympla voce vende ingressos. Na Aura voce gerencia seu negocio inteiro" — WISHFUL THINKING

Essa mensagem pressupoe que produtores de eventos no Brasil (na sua maioria MEIs que fazem festas de 200-500 pessoas) precisam de "gerenciamento de negocio inteiro." A realidade: **eles precisam vender ingressos.** O resto e nice-to-have. CRM, calculadoras financeiras, certificados — tudo isso e irrelevante para um promoter que faz uma festa por mes em uma casa noturna. A mensagem ressoa com consultores de McKinsey, nao com o publico-alvo real.

---

## 4. ESTRATEGIA GO-TO-MARKET: COMO NAO ROUBAR CLIENTES DE UM MONOPOLIO

O plano de aquisicao de clientes do Aura e o ponto mais fragil de toda a estrategia.

### 4.1. "Eventos pilotos gratuitos nos primeiros 3 meses" — ESTRATEGIA DE QUEIMAR DINHEIRO

A ideia de oferecer 3 eventos gratis para atrair produtores soa bem em uma apresentacao, mas ignora a fisica do mercado:

- Cada "evento piloto" exige **onboarding manual, suporte tecnico, configuracao de pagamentos e acompanhamento pos-evento.** Isso consome 5-10 horas de trabalho por produtor.
- Produtores que aceitam coisas gratis tem **taxa de conversao para pagante de 5-10%** (benchmark freemium B2B).
- O custo de oportunidade de atender 50 produtores gratis (D3 projeta 50 produtores no mes 3) para converter 2-5 em pagantes e um **CAC implicito de R$ 6.000-15.000 por cliente** — inviavel.

### 4.2. A ausencia de canal de aquisicao definido

O plano nao define:
- Orcamento de marketing (zero linha orcamentaria)
- Canais de aquisicao (SEO, ads, outbound, parcerias?)
- Equipe comercial (quem vende?)
- Tempo de ciclo de vendas (benchmark: 30-90 dias para SaaS B2B no Brasil)

A projecao de 500 produtores em 12 meses sem um plano de aquisicao documentado e **deliberacao, nao estrategia.**

### 4.3. A realidade da migracao de plataforma

Mudar de Sympla para Aura nao e como trocar de app de musica. Envolve:
- Migracao de dados historicos de participantes
- Treinamento da equipe em nova interface
- Risco de falha tecnica no dia do evento (o pesadelo de qualquer produtor)
- Perda de visibilidade no marketplace da Sympla (38M de acessos/mes)

**Nenhum produtor razoavel troca uma plataforma que funciona por uma que nunca processou um evento real — mesmo que seja mais barata.**

---

## 5. MODELO DE RECEITA RECORRENTE (SaaS): CHUTES DISFARCADOS DE ESTRATEGIA

Os planos de assinatura (Gratis/Pro R$149/Business R$399/Enterprise R$999) parecem baseados em benchmarks internacionais (TicketSauce cobra US$99-299/mes), mas **sem adaptacao para a realidade brasileira.**

### 5.1. Quem pagaria R$ 999/mes?

O plano Enterprise pressupoe que empresas como Woods, D-Edge ou Green Valley pagariam R$ 999-2.000/mes por white label. Mas essas empresas **ja tem sistemas proprios ou contratos com a Sympla Enterprise.** Para justificar R$ 999/mes, o Aura precisaria oferecer:
- Suporte 24/7 com SLAs (precisa de equipe)
- Onboarding dedicado (precisa de equipe)
- API estavel (nao existe ainda)
- Uptime garantido de 99,9% (sem historico operacional)

**Nenhuma empresa seria pagaria R$ 999/mes por um white label sem tracao comprovada.**

### 5.2. O plano Gratis e a armadilha do freemium

O plano Gratis (100 ingressos/mes, taxa 7%, marca Aura visivel) atraira 90% dos usuarios. O problema: cada usuario gratis custa dinheiro (suporte, infraestrutura, processamento de pagamentos). Se 90% dos usuarios ficarem no plano Gratis, a Aura queima caixa atendendo usuarios que nunca pagarao.

### 5.3. Taxa de conversao freemium realista

A industria SaaS B2B tem taxa de conversao freemium-pago de **2-5%**. Para atingir 200 assinantes pagantes (projecao D3), a Aura precisaria de **4.000-10.000 produtores cadastrados.** Em 12 meses, com zero marca. Impossivel.

---

## 6. TAM/SAM/SOM: O MERCADO DE R$ 250 BILHOES NAO EXISTE

O documento afirma que "o mercado de eventos no Brasil movimenta anualmente cerca de R$ 250 bilhoes." **Isso e falso.**

### Dados reais:
- A ABRAPE (Associacao Brasileira de Promotores de Eventos) projeta **R$ 141,1 bilhoes em 2025**.
- Em 2024, o consumo foi de R$ 131,8 bilhoes.
- O valor de R$ 250 bilhoes parece vir de uma estimativa pre-pandemia (2019: R$ 209 bilhoes) inflacionada.

**A Aura inflacionou seu TAM em ~77%** — um erro que nao seria tolerado em qualquer pitch para investidor institucional.

### Decomposicao realista:

| Metrico | Valor Real | O que a Aura usa |
|---------|-----------|-----------------|
| TAM (eventos no Brasil) | R$ 141B | R$ 250B (77% inflado) |
| SAM (eventos com ticketing online) | ~R$ 15-20B | R$ 50B+ (estimativa Aura) |
| SOM (alcançavel em 3-5 anos) | R$ 50-100M | R$ 500M+ (fantasia) |

O SOM realistico da Aura em 3-5 anos, se tudo der certo, e de **R$ 5-15M/ano** — nao R$ 500M. O mercado de ticketing online no Brasil e dominado pela Sympla, que ja processou 110M de ingressos. Entrar nesse mercado exige anos de investimento.

---

## 7. HIPOTESES CENTRAIS: O QUE PRECISA SER VERDADE PARA A AURA DAR CERTO

O modelo de negocio da Aura depende de pelo menos **8 hipoteses altamente arriscadas** serem verdadeiras simultaneamente:

### Hipoteses de Produto (Risco Medio)
1. **A integracao de 66 paginas mock com backend real levara 4-8 semanas.** O D9 ja admite que "sera substancialmente maior" e estima 6-10 semanas com 2 devs. Realisticamente: 12-20 semanas.
2. **O sistema de split de pagamentos via Stripe Connect/Woovi funcionara sem problemas regulatorios no Brasil.** O Banco Central exige registro para arranjos de pagamento. A Stripe Connect simplifica, mas nao elimina essa burocracia.

### Hipoteses de Mercado (Risco Alto)
3. **Produtores de eventos trocarao a Sympla por uma plataforma sem tracao para economizar 3-5% em taxas.** Historico de mercado diz que nao — confiabilidade > preco em B2B.
4. **O mercado brasileiro tem demanda suficiente por white label para sustentar um modelo SaaS de R$ 199-999/mes.** Nao ha evidencia empirica disso. TicketSauce funciona nos EUA (mercado 10x maior). No Brasil, o numero de produtores que precisam de white label e minusculo.
5. **A taxa de churn sera <5% ao mes.** Sem historico operacional, isso e um palpite.

### Hipoteses Operacionais (Risco Altissimo)
6. **O gateway de pagamento sera definido e integrado sem problemas.** O documento D9 admite que "o gateway sera decidido depois." Uma plataforma de ticketing sem gateway definido e como um restaurante sem fornecedor de alimentos.
7. **A Aura conseguira 500 produtores ativos em 12 meses sem investimento significativo em marketing.** Isso exigiria um crescimento organico que nenhuma startup B2B brasileira alcancou sem investimento em vendas.
8. **A Sympla nao reagira com precos menores ou funcionalidades adicionais.** Isso e impossivel. A Sympla ja reagiu a saida da Eventbrite ampliando atendimento. Se a Aura ameacar 1% do mercado, a Sympla lanca white label em 3 meses.

**Se QUALQUER UMA dessas hipoteses falhar, o modelo quebra.** A probabilidade estatistica de todas 8 se confirmarem e baixissima.

---

## 8. RISCOS CRITICOS NAO ENDEREÇADOS

### 8.1. O Risco Regulatorio (Aprenda com a Eventbrite)
A Eventbrite, gigante global, **saiu do Brasil em janeiro de 2026** por "instabilidade regulatoria." A Aura ignora completamente esse risco. O mercado de pagamentos no Brasil e um dos mais regulamentados do mundo. A plataforma precisara de:
- Registro como plataforma de pagamento (ou usar a licenca do gateway)
- Compliance com LGPD (apenas mencionado)
- KYC rigoroso de todos os produtores
- Prevencao a lavagem de dinheiro (eventos sao canal conhecido)

### 8.2. O Risco de Chargeback
O D9 menciona que "pagamentos de eventos tem alto indice de chargeback." Isso e um eufemismo. **Chargeback em eventos e extremamente alto no Brasil** (3-5% vs. 0,5-1% em e-commerce normal). Se um produtor fraudulento gerar chargebacks, a conta da Aura no Stripe pode ser bloqueada — e toda a operacao para.

### 8.3. O Risco Tecnologico: "A Ilusao do 95% Pronto"
O D9 honestamente admite que "substituir mocks por integracoes reais envolve refatorar logica de estados, tratamento de erros, loading states, paginacao real." O que o documento nao diz: isso costuma levar **2-3x mais tempo que a implementacao original.** Com 66 paginas e 82 componentes, a equipe esta olhando para **6-12 meses de trabalho de integracao** — nao 4-8 semanas.

### 8.4. O Risco de Capital
O plano de investimento e de R$ 145-220K em 12 meses. Com CAC de R$ 3-8K (SaaS B2B Brasil), esse valor compra **18-73 clientes.** A projecao de 200 assinantes em 6 meses exigiria R$ 600K-1,6M em investimento de aquisicao. **O capital planejado e 5-10x menor que o necessario.**

---

## O QUE ESTA BOM (REALMENTE)

Nem tudo e ruim. O projeto Aura tem ativos reais:

1. **O frontend de 66 paginas e 82 componentes** e um ativo significativo. Se estiver bem codificado, economiza 6-12 meses de trabalho de desenvolvimento.
2. **O Seating Map com Canvas HTML5** e um diferencial tecnico real. Nenhum concorrente brasileiro tem algo equivalente.
3. **O split de pagamentos** e uma oportunidade real. Mesmo que a Sympla ofereca parcialmente, a transparencia do "dinheiro na conta em D+1" e um argumento de venda legitimo.
4. **A decisao do D9 de adiar o POS Cashless** e sapiencia pura. Reconhecer que o POS e um produto separado que exige logistica fisica evita um desastre operacional.
5. **A stack tecnologica (Supabase + Vercel)** e adequada para MVP. Baixo custo fixo, escala serverless.
6. **O specdrive de 124 paginas** demonstra pensamento estrategico disciplinado — raro em startups nessa fase.

---

## RECOMENDACOES ESTRATEGICAS

### Recomendacao 1: Esqueca a projecao de R$ 8,88M. Planeje para R$ 150K no ano 1.
Use a projecao conservadora do D9 como BASE, nao como cenario pessimista. Um plano de negocio realista da a equipe credibilidade interna e com investidores.

### Recomendacao 2: Defina o gateway ANTES de escrever uma linha de codigo a mais.
Sem gateway definido, nao ha negocio. Contrate um advogado especialista em regulacao de pagamentos do BC. O risco regulatorio e existencial.

### Recomendacao 3: Foque em um nicho microscopico nos primeiros 12 meses.
Nao tente ser "ecossistema completo." Seja "a melhor plataforma para festas eletronicas em Sao Paulo" — ou outro nicho pequeno. Domine um nicho, depois expanda.

### Recomendacao 4: Reveja os precos para cima.
5-7% e insustentavel. Comece com 7-8% e ofereca valor justificavel. E melhor ter 50 clientes pagando 8% do que 200 clientes pagando 5% e quebrando sua operacao.

### Recomendacao 5: Documente um plano de aquisicao com numeros reais.
Com quanto dinheiro? Em quais canais? Com quem vendendo? Sem isso, as projecoes sao ficcao.

### Recomendacao 6: Trate o projeto como um R&D de 18-24 meses, nao um rocket ship de 12 meses.
O mercado de ticketing nao tem "growth hacking." Tem vendas B2B dificeis, suporte operacional pesado e anos de construcao de confianca. Quem disser o contrario esta mentindo.

---

## CONCLUSAO FINAL

O Aura tem **um nucleo de valor real** (split de pagamentos + white label conceitual) e **um ativo de frontend valioso.** Mas seu plano de negocio sofre de uma doenca comum em startups brasileiras: **otimismo seletivo embalado em planilhas bonitas.** A projecao de R$ 8,88M em 12 meses nao e otimismo — e delirio. A analise competitiva ignora concorrentes reais e omite fatos inconvenientes (Eventbrite saindo, Sympla com 350K produtores, TAM inflado em 77%).

**A chance de Product-Market Fit do Aura nao e "ALTA" como o D9 afirma.** E MEDIA-BAIXA — condicional a execucao tecnica perfeita, timing de mercado favoravel e ausencia de reacao da Sympla. Tres condicoes que raramente se alinham.

O projeto tem potencial para incomodar a Sympla em um nicho especifico (produtores insatisfeitos que querem split e white label), mas **nunca sera um ecossistema de R$ 8,88M em 12 meses.** Se a equipe aceitar essa realidade e pivotar para um plano de 24-36 meses com foco cirurgico, o Aura pode se tornar uma operacao sustentavel de R$ 1-3M/ano. E isso, no mercado brasileiro de SaaS, ja seria um sucesso.

---

*Analise produzida com base nos documentos D0, D1/D2, D3 e D9 do projeto Aura, pesquisa de mercado em fontes primarias (ABRAPE, Sympla, Stripe, Woovi) e benchmarks de industria SaaS B2B Brasil.*

*Autor: Analista Estrategico Senior | Junho 2025*
