# Analise Critica de Arquitetura e Tecnologia: Aura Platform

**Autor:** Arquiteto de Software Senior | Sistemas Distribuidos e Pagamentos
**Data:** Maio 2025 | **Documentos Analisados:** D5, D6, D8, D10, D11, D12

---

## 1. Schema do Banco: 30 Tabelas com Falhas Estruturais

O schema em D5 cobre os dominios do problema, mas comete erros que causarao dor significativa em producao.

**Tabelas core ausentes.** A `producer_profiles` e mencionada em D11 (`company_name`, `cnpj`, `stripe_account_id`, `commission_rate`, `is_verified`) mas **nao consta no schema do D5**. Sem ela, nao ha como fazer KYC de produtores, split de pagamentos via Stripe Connect, nem aplicar limites progressivos (R$5K primeiro mes) — funcionalidades que o proprio D11 declara como "decisoes ja tomadas". O campo `stripe_customer_id` na tabela `users` e insuficiente: produtores precisam de `stripe_connect_account_id` (para receber via Connect), nao de `stripe_customer_id` (que e para pagar como cliente). A confusao entre esses dois conceitos e basica e perigosa.

**Nomenclatura conflitante.** O D5 chama a tabela de `users`, mas D8 (`src/types/database.ts`, linha 167) a chama de `profiles`. As FKs em `events`, `tickets`, `orders` apontam para `users(id)`, mas os hooks em D8 consultam `profiles`. Isso quebra toda a aplicacao — nao e escolha de design, e inconsistencia fatal que impede qualquer query de funcionar.

**Normalizacao quebrada.** A tabela `events` tem 13 campos de venue hardcoded (`venue_name` ate `venue_lng`) em vez de FK para tabela `venues`. Um produtor com 50 eventos no mesmo local repete endereco 50 vezes. Nao ha tabela de `categories` — o campo e `TEXT` livre, garantindo duplicatas ("Musica", "musica", "MUSICA") e impedindo hierarquias. A tabela `orders` duplica `customer_name`, `customer_email`, `customer_cpf`, `customer_phone` da tabela `users`, criando fonte de verdade duplicada sem justificativa (orders.user_id ja e NOT NULL e referencia users).

**Indexes insuficientes.** Nao ha index composto `(status, start_date)` — a query mais comum da aplicacao ("eventos publicados, ordenados por data"). A tabela `tickets` nao tem index em `(event_id, status)`, essencial para operacao de check-in em escala. O `idx_tickets_qr` e redundante (qr_code ja e UNIQUE). JSONB em `events.settings` e `events.branding` sem schema de validacao nem CHECK constraints — cada evento tera estrutura diferente.

**ON DELETE CASCADE perigoso.** `ticket_types` tem CASCADE em `event_id`. Delete um evento e todos os tipos de ingresso somem. Sem soft delete (`deleted_at`) em nenhuma tabela, a delecao e permanente. Para ticketing, isso e inaceitavel — deveria ser `ON DELETE RESTRICT` ou soft delete com trigger de arquivamento.

**Materialized View quebrada.** A `event_summary` usa `REFRESH MATERIALIZED VIEW CONCURRENTLY`, mas concurrent refresh exige index UNIQUE na view. O D5 cria indexes em `producer_id` e `status`, mas **nao em `event_id`** (a PK da view). O refresh vai falhar. A view usa `COUNT(DISTINCT t.id)` onde `COUNT(t.id)` basta — `DISTINCT` e custoso e desnecessario para um campo ja unico.

---

## 2. RLS Policies: Vazamentos de Dados Garantidos

**A lenda do `(select auth.uid())`.** D12 (skill aura-backend) ensina usar `(select auth.uid())` em vez de `auth.uid()` "por performance — diferenca de 3 minutos para 2ms em tabelas grandes". Isso e **tecnicamente incorreto**. A funcao `auth.uid()` do Supabase e `STABLE` — PostgreSQL a avalia uma vez por query, nao por linha. O `select` adiciona overhead de parsing desnecessario. Essa recomendacao e um sinal claro de que quem escreveu as skills nao entende otimizacao de PostgreSQL — e essas skills estao treinando os agentes de IA.

**Vulnerabilidade em `ticket_types`.** A policy:
```sql
FOR SELECT USING (
  is_active = TRUE AND EXISTS (...published)
  OR EXISTS (...producer_id = auth.uid())
);
```
O `AND` tem precedencia sobre `OR`, entao a expressao equivale a `(A AND B) OR C`. Um usuario autenticado pode ler **qualquer ticket_type** se for producer do evento — mesmo inativo, mesmo de evento draft. Alem disso, a policy nao especifica `TO authenticated`/`TO anon`, expondo dados para usuarios nao autenticados dependendo da avaliacao com `auth.uid()` = NULL. O pattern correto seria usar parenteses explicitos: `(is_active AND evento_publico) OR (usuario_e_produtor)`.

**Tabelas com RLS habilitado mas zero policies.** `check_ins` e `communications` tem `ENABLE ROW LEVEL SECURITY` mas **nenhuma policy definida**. Com RLS ativado e zero policies, ninguem pode ler/inserir nada via API direta. A Edge Function de check-in usa `service_role_key` (funciona), mas qualquer leitura do painel do produtor (estatisticas de entrada em tempo real) e bloqueada. Nao ha policy `FOR INSERT` em `order_items` — criar um pedido completo via API direta e impossivel sem service_role, forcouando toda criacao de pedido a passar por Edge Function.

**Tabela `customers` (CRM) sem policies.** Com RLS habilitado e sem policies, dados de CRM de todos os produtores ficam inacessiveis. Se RLS estiver desabilitado, todos acessam tudo. Ambos quebram o produto — e nao ha mencao de qual cenariu foi intencional.

---

## 3. Edge Functions: Inseguras, com Race Conditions Criticas

**`stripe-webhook`: Race condition catastrofica.** A funcao gera tickets em loop N+1:
```typescript
for (const item of order.order_items) {
  for (let i = 0; i < item.quantity; i++) {
    await supabase.from("tickets").insert({...}); // N chamadas de rede!
  }
}
```
Se o webhook for chamado 2x (retries de rede do Stripe sao padrao — timeout de 30s, falha de DNS, restart de Edge Function), **tickets duplicados serao gerados**. Nao ha verificacao de idempotencia (`order_id` na tabela `tickets` nao tem UNIQUE constraint). Para um pedido de 10 ingressos, a funcao faz 1 update em orders + 1 update em payments + 1 select com join + 10 inserts + queries de split = **14 chamadas de rede sequenciais**. Se a funcao falhar apos atualizar `orders` mas antes de gerar todos os tickets, o cliente pagou sem receber todos os ingressos. Nao ha transacao PostgreSQL, nem tabela `webhook_events` para rastrear processamento, nem pattern saga com compensacao. O codigo do split com Stripe Connect esta **truncado no documento** (linha 693) — nao ha implementacao do `Transfer`, nem verificacao se a conta Connect do produtor esta ativa.

**`woovi-webhook`: Sem validacao de assinatura.**
```typescript
const { charge } = await req.json();
if (charge.status === "COMPLETED") { ... }
```
Qualquer pessoa com a URL do webhook pode forjar um request e marcar ordens como pagas. A API da Woovi suporta validacao via header de assinatura (`X-OpenPix-Signature`), mas o D5 nao implementa. **Vulnerabilidade critica**: atacante pode descobrir a URL do endpoint (Supabase Functions sao publicas por padrao) e gerar tickets sem pagar nada, causando prejuizo direto.

**`woovi-create-pix`: Erro de unidade.** Faz `Math.round(amount)` em vez de `Math.round(amount * 100)`. Se `amount` = 29.90, envia 30 centavos em vez de 2990 centavos para a API. Pix trabalha em centavos — esse e um bug que cobraria 1/100 do valor correto. A funcao do Stripe (`stripe-create-payment`) corretamente faz `amount * 100`, mostrando inconsistencia entre as implementacoes.

**`send-email`: Endpoint aberto para spam.** Aceita `to`, `subject`, `html` arbitrarios sem validacao JWT. Qualquer um com a URL usa a API key do Resend do projeto para enviar spam ilimitado — custo direto ao dono. A funcao deveria receber apenas `order_id` e buscar destinatario no banco.

**`check-in-validate`: Falta de atomicidade.** Faz `UPDATE tickets` + `INSERT check_ins` sem transacao. Se o update funcionar mas o insert falhar (network glitch), o ingresso fica `used` sem registro de quem fez o check-in. Alem disso, usa `.single()` na busca — se QR code nao existir, lanca excecao nao tratada (erro 500 generico em vez de 404 controlado).

---

## 4. Escolha de Stack: Ferramentas Erradas para o Problema

**Supabase como BaaS para pagamentos.** Supabase e excelente para CRUD e auth. Para plataforma de pagamentos, e insuficiente sozinho. Falta: idempotencia de webhooks, reconciliacao financeira, saga pattern para operacoes compostas, filas com retry e backoff exponencial, tracing distribuido. Usar Edge Functions do Supabase para logica de pagamento e usar a ferramenta errada — deveria ser backend proprio (Node.js/Go/Python) com filas (SQS/RabbitMQ) e controle transacional.

**HashRouter + SPA = SEO inexistente.** React 19 com Vite e HashRouter produz URLs como `aura.events/#/event/slug`. Isso **nao e indexavel** pelo Google — o conteudo nao existe no HTML inicial. Para ticketing, onde cada evento precisa aparecer em busca organica ("show rock Sao Paulo"), isso e suicidio de aquisicao. O Google ignora tudo apos `#` — cada evento tem a mesma URL para o crawler. Next.js com SSR/SSG resolveria nativamente, gerando HTML estatico por evento. Vercel e feito para Next.js — usar Vite + SPA e desperdicar a infraestrutura.

**Deep links quebrados.** Compartilhar `aura.events/#/event/abc` no WhatsApp/Instagram requer rewrite no servidor. O `vercel.json` ate tem rewrite `/(.*) -> /index.html`, mas crawlers e previews de link (WhatsApp, Facebook, Twitter) nao executam JavaScript — veem pagina em branco. O Open Graph e impossivel sem SSR.

---

## 5. Arquitetura de Pagamentos: Adiamento de Decisao Critica

**"Gateway-agnostic" nao funciona para split.** O adapter pattern de D10 assume interface unica (`processPayment()`, `generatePix()`), mas cada gateway tem modelo de split fundamentalmente diferente:
- Stripe Connect: `Transfer` objects, `destination` charges, onboarding KYC obrigatorio por produtor
- Woovi: `splits` array na criacao da cobranca, com `accountId` de cada recebedor
- PagSeguro: repasses programados, API completamente diferente
- Mercado Pago: `marketplace_fee` + `split_payments`

Nao ha "menor denominador comum" que abstraia isso sem perder funcionalidade. O adapter seria tao complexo quanto implementar cada gateway separadamente, mas limitado ao que todos suportam.

**PCI-DSS ignorado.** O D10 propoe `CreditCardForm.tsx` que coleta numero de cartao, CVV e validade diretamente no frontend. Com Stripe, isso e **proibido sem PCI DSS** — o correto e Stripe Elements (iframe seguro, dados nunca tocam seu codigo). O formulario proposto so funciona para gateways diretos, que exigem certificacao PCI DSS nivel 1 — processo que leva meses e custa milhares de dolares anuais.

**Multi-gateway e loucura para 1 dev.** D6 propoe Stripe + Woovi + PagSeguro (backup). Isso significa 3 contas a gerenciar, 3 dashboards de conciliacao, 3 webhooks para manter, 3 APIs com comportamentos diferentes, 3 taxas para explicar ao produtor. Para 1 dev em 4 semanas, e impossivel. Regra pratica de mercado: escolha 1 gateway, lance, adicione o segundo com tracao comprovada.

---

## 6. Estimativas de Tempo: 3-4x Otimistas

**"4 semanas para P0 com 1 dev" e fantasia descolada da realidade.**

| Etapa | Estimativa D11 | Estimativa Realista (1 dev senior) |
|-------|---------------|-----------------------------------|
| Schema 30 tabelas + ajustes | 2-3 dias | 4-5 dias |
| RLS + Triggers (testar cada policy) | 1-2 dias | 4-6 dias |
| Zustand Stores + testes | 4-6 horas | 2-3 dias |
| TanStack Query Hooks + cache | 6-8 horas | 4-6 dias |
| Substituir 66 paginas de mocks | 2-3 dias | 8-12 dias |
| 20 componentes de pagamento | 3-4 dias | 8-12 dias |
| 10 Edge Functions + webhooks | 2-3 dias | 6-10 dias |
| Testes integrados + bug fixes | 3-5 dias | 8-12 dias |
| **TOTAL** | **~16 dias** | **~44-66 dias = 9-13 semanas** |

Isso sem contar: configuracao de contas nos gateways (Stripe Connect onboarding e complexo, requer verificacao de identidade que pode levar dias), testes de integracao com sandbox + producao, responsive para 66 paginas, acessibilidade, e performance (Core Web Vitals). O D6 diz "5.5 horas para infra pronta" — isso assume que 30 tabelas + 50 policies + 15 triggers funcionam na primeira tentativa (nunca acontece) e que Stripe Connect nao precisa de KYC (precisa).

---

## 7. Seguranca: Vulnerabilidades Nao Mapeadas

**XSS via localStorage.** O cliente Supabase (D8) usa `persistSession: true` com localStorage. Tokens JWT ficam acessiveis a qualquer script de terceiro (Pixel Facebook, GTM, chat widgets, CDN comprometido). O Supabase suporta `cookie-based auth` com httpOnly cookies, mas nao foi configurado. Para site de eventos que tipicamente carrega dezenas de scripts de tracking, o risco de XSS via supply chain e alto.

**Headers de seguranca incompletos.** Os headers em `vercel.json` incluem `X-XSS-Protection` (obsoleto desde 2019, Chrome e Firefox ignoraram), mas **faltam headers criticos**:
- `Content-Security-Policy` — essencial para impedir execucao de scripts nao autorizados
- `Strict-Transport-Security` (HSTS) — obrigatorio para site de pagamentos
- `Permissions-Policy` — desabilitar camera, microphone, geolocation se nao usados

**Rate limiting inexistente.** A variavel `API_RATE_LIMIT=100` aparece no `.env` mas nao ha implementacao em nenhuma Edge Function. Atacante pode fazer brute force em QR codes (`/check-in-validate`) para encontrar ingressos validos, ou spam no `/send-email` ilimitadamente.

**SQL Injection potencial.** O hook `useEvents` em D8 faz:
```typescript
if (filters?.search) query = query.ilike('title', `%${filters.search}%`)
```
A interpolacao de string e anti-pattern. Se `filters.search` vier de URL params nao sanitizados, ha vetor de injection no PostgREST. O cliente Supabase escapa parametros em queries estaticas, mas a construcao dinamica com concatenacao de string e fragil.

**LGPD ignorada.** A tabela `orders` armazena `customer_cpf` e `customer_phone`. Com RLS atual, produtores leem CPF de todos os compradores de seus eventos. Nao ha campo de consentimento (`consent_data_usage`), criptografia de campos sensiveis, nem anonimizacao apos prazo. Em caso de vazamento, a plataforma responde civil e criminalmente por exposicao de dados pessoais sem base legal.

---

## 8. Escalabilidade: O Que Quebra Primeiro

**Supabase Pro: limites reais.** $25/mes = 8GB banco, 100K Edge Function calls/mes, 100 conexoes concorrentes. Com 1000 eventos e 100 compras/evento = 100K compras. Cada compra gera 4-15 chamadas (webhook + tickets + email + updates) = 400K-1.5M calls/mes. O limite de 100 conexoes esgota rapidamente: cada usuario ativo mantem WebSocket (Realtime) + faz queries + dispara Edge Functions.

**Gargalos identificados:**
1. **Edge Functions**: Sem paralelismo no processamento de webhooks. Pico de vendas (lancamento de ingresso para show grande) = webhooks enfileirados, timeout de 50s, retries do Stripe, perda de eventos e tickets nao gerados.
2. **Geracao de tickets**: Loop N+1 no webhook. 500 ingressos vendidos = 500 inserts sequenciais via API. Sem batch insert, sem fila, sem processamento assincrono.
3. **Materialized View**: Refresh locka leituras do dashboard. Sem `CONCURRENTLY` funcional (falta unique index na PK), produtores veem dados stale ou timeouts.
4. **Sem cache de API**: Cada pagina de evento bate direto no banco. Sem Redis, sem CDN para API, sem cache no edge da Vercel. O banco e atacado a cada pageview.

---

## 9. Antigravity + Agentes de IA: Produtividade Fantasiosa

**"Exercito de 12 agentes" nao existe.** LLMs sao autocompletar sofisticado, nao desenvolvedores autonomos. Eles nao entendem contexto de negocio, nao debugam integracoes complexas que exigem contas reais em gateways de pagamento, nao conseguem reproduzir bugs de race condition em producao, e frequentemente "alucinam" APIs e patterns que nao existem.

**O `(select auth.uid())` e sintoma.** A "skill" de backend (D12) ensina incorretamente que `(select auth.uid())` e mais rapido que `auth.uid()`. Se o "Arquiteto" agente projetar o schema com essa informacao falsa, o sistema sera systematicamente flawed em toda sua camada de seguranca.

**11 ciclos de workflow = burocracia improdutiva.** Fases como "Auditoria" (agente revisa seguranca), "Correcao" (debugger acha bugs), "Validacao" (testa em staging) — nenhuma funciona na pratica. Agentes de IA verificam padroes sintaticos, nao vulnerabilidades logicas; nao encontram race conditions; nao conseguem reproduzir bugs que dependem de estado de rede; nao conseguem avaliar se uma UX faz sentido.

**Uso correto: copiloto, nao substituto.** Agentes de IA sao uteis para: boilerplate, refatoracoes mecanicas, gerar testes unitarios, explicar codigo legado. Nao para: arquitetar bancos de dados, implementar logica de pagamentos, garantir seguranca, tomar decisoes de stack. Cada "missao" gera output que **precisa ser revisado por humano experiente** — e o overhead de revisao e correcao de codigo de IA frequentemente excede o ganho de produtividade para tarefas complexas.

---

## 10. Custos Reais: Ilusao de $46/mes

**Custos fixos omitidos pelo D6:**

| Item | D6 diz | Custo Real |
|------|--------|-----------|
| Supabase | $25 | $75-300 (escala com banco + Realtime + Storage + bandwidth) |
| Resend | "Gratis (3K/dia)" | $0-50 (acima de 3K/dia, que e rapido com 1000 eventos) |
| Sentry | "Gratis (5K erros)" | $0-26 (acima de 5K erros, comum em SPA com 66 paginas) |
| Backups PITR | Nao mencionado | $25-50 (absolutamente necessario para dados financeiros) |
| SSL multi-subdomain | Nao mencionado | $0-50 (white label requer certificados wildcard) |
| **Fixo real** | **~$46** | **$120-500/mes** |

**Custos variaveis enormes e nao modelados:**
- Stripe: 2.9% + R$0.30 por transacao de cartao
- Woovi: 0.99% por transacao Pix
- Taxa plataforma Aura: 5-7% (D11)

Em R$100 mil em vendas mensais: R$2.900 (Stripe) + R$990 (Woovi) + R$5.000-7.000 (plataforma) = **R$9-11K em taxas sobre receita**. O D6 omite completamente essa analise, focando apenas no "custo fixo acessivel".

**Custo de oportunidade.** Com estimativas 3-4x otimistas, cada semana de atraso e receita adiada, concorrentes avancando, e momentum perdido. Usar IA como substituto de desenvolvedor senior, em vez de acelerador de devs experientes, gera retrabalho que custa mais que contratar um engenheiro por 8 semanas.

---

## Conclusao: Diagnostico e Recomendacoes

### Diagnostico
A Aura tem boa visao de produto (plataforma de eventos e necessidade real do mercado) mas execucao tecnica fragil. Os documentos D5-D12 demonstram conhecimento superficial de varias tecnologias combinado com falta critica de experiencia em sistemas de pagamentos em producao. Os problemas nao sao cosmeticos — sao estruturais: schema incompleto, RLS com vulnerabilidades, webhooks sem idempotencia, arquitetura de pagamentos nao definida, e estimativas de tempo irreais.

### Recomendacoes Imediatas

| Prioridade | Acao | Por que |
|-----------|------|---------|
| **P0** | Definir gateway AGORA (recomendo: Stripe Connect so) | Desbloqueia toda arquitetura; elimina complexidade de multi-gateway |
| **P0** | Corrigir schema: `producer_profiles`, soft delete, `webhook_events` | Base solida para operacao financeira sem perda de dados |
| **P0** | Reescrever `stripe-webhook` com idempotencia e transacao | Previne tickets duplicados e vendas perdidas — o core do negocio |
| **P1** | Validar assinatura no `woovi-webhook`; corrigir `amount * 100` | Fecha vulnerabilidade de forjamento e bug de cobranca |
| **P1** | Adicionar CSP, HSTS, rate limiting nas Edge Functions | Compliance basico para plataforma de pagamentos |
| **P1** | Migrar HashRouter → Next.js com SSR (ou BrowserRouter) | SEO e compartilhamento — canais de aquisicao |
| **P2** | Implementar fila de processamento; observabilidade | Escalabilidade e operacao em producao |
| **P3** | Usar agentes de IA como COPILOTO, nao equipe | Expectativas realistas de produtividade |

### Veredicto Final
O projeto precisa de **um engenheiro senior de backend liderando por 6-8 semanas** antes de qualquer agente de IA tocar no codigo de pagamentos ou seguranca. Decisoes de arquitetura (schema, RLS, webhooks, split) requerem julgamento baseado em anos de experiencia com sistemas financeiros em producao — nao sao automatizaveis por LLMs. Use IA para acelerar implementacao DEPOIS que as decisoes estiverem tomadas e documentadas. Usar IA para TOMAR decisoes criticas e construir sobre areia movedica — e o caminho mais rapido para um lancamento catastrofico.

---

*Analise baseada exclusivamente nos documentos D5, D6, D8, D10, D11, D12. Nenhum codigo de producao foi inspecionado — esta avaliacao se limita ao que foi documentado nos specs.*
