import { useState } from 'react'
import { TrendingUp, TrendingDown, DollarSign, Download } from 'lucide-react'

export default function ProducerFinance() {
  const [period, setPeriod] = useState('month')

  const transactions = [
    { id: '1', event: 'Noite Eletro 2025', type: 'income', amount: 2840, date: '14 Mai 2025', tickets: 12 },
    { id: '2', event: 'Jazz Sunset Session', type: 'income', amount: 960, date: '13 Mai 2025', tickets: 8 },
    { id: '3', event: 'Taxa de Plataforma', type: 'fee', amount: -380, date: '13 Mai 2025', tickets: 0 },
    { id: '4', event: 'Noite Eletro 2025', type: 'income', amount: 4260, date: '12 Mai 2025', tickets: 18 },
    { id: '5', event: 'Feira de Arte', type: 'income', amount: 540, date: '11 Mai 2025', tickets: 12 },
    { id: '6', event: 'Reembolso', type: 'refund', amount: -120, date: '10 Mai 2025', tickets: -1 },
  ]

  const stats = [
    { label: 'Receita Total', value: 'R$ 45.680', change: '+12%', up: true, icon: DollarSign },
    { label: 'Ticket Medio', value: 'R$ 128', change: '+5%', up: true, icon: TrendingUp },
    { label: 'Taxas', value: 'R$ 3.820', change: '-2%', up: false, icon: TrendingDown },
    { label: 'Liquido', value: 'R$ 41.860', change: '+14%', up: true, icon: DollarSign },
  ]

  return (
    <div className="p-6 lg:p-10 max-w-7xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-serif text-3xl text-espresso">Financeiro</h1>
          <p className="text-sm text-espresso/50 mt-1">Acompanhe suas vendas e receitas</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-white/60 border border-white/60 rounded-full p-1">
            {['week', 'month', 'year'].map(p => (
              <button key={p} onClick={() => setPeriod(p)} className={`px-4 py-1.5 text-xs font-medium rounded-full transition-all ${period === p ? 'bg-plum text-cream' : 'text-espresso/50 hover:text-espresso'}`}>
                {p === 'week' ? 'Semana' : p === 'month' ? 'Mes' : 'Ano'}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 border border-espresso/15 text-espresso text-sm rounded-full hover:bg-espresso/5 transition-all">
            <Download className="w-4 h-4" />
            Exportar
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="p-5 rounded-2xl bg-white/60 border border-white/60 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <s.icon className="w-5 h-5 text-plum" />
              <span className={`text-xs font-medium ${s.up ? 'text-green-600' : 'text-red-500'}`}>{s.change}</span>
            </div>
            <div className="font-serif text-2xl text-espresso">{s.value}</div>
            <div className="text-xs text-espresso/40 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Chart placeholder */}
      <div className="mb-8 p-6 rounded-2xl bg-white/60 border border-white/60 backdrop-blur-sm">
        <h2 className="font-serif text-xl text-espresso mb-6">Faturamento</h2>
        <div className="h-48 flex items-end gap-2">
          {[35, 55, 40, 70, 45, 80, 60, 75, 50, 85, 65, 90].map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full rounded-t-lg bg-plum/30 hover:bg-plum/50 transition-colors" style={{ height: `${h * 2}px` }} />
            </div>
          ))}
        </div>
        <div className="flex justify-between mt-3">
          {['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'].map(m => (
            <span key={m} className="flex-1 text-center text-[10px] text-espresso/30">{m}</span>
          ))}
        </div>
      </div>

      {/* Transactions */}
      <div className="bg-white/60 border border-white/60 rounded-2xl overflow-hidden backdrop-blur-sm">
        <div className="p-6 border-b border-espresso/5 flex items-center justify-between">
          <h2 className="font-serif text-xl text-espresso">Transacoes</h2>
          <button className="text-xs text-plum hover:underline">Ver todas</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-espresso/5">
                <th className="text-left px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Evento</th>
                <th className="text-left px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Tipo</th>
                <th className="text-left px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Data</th>
                <th className="text-right px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Valor</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map(t => (
                <tr key={t.id} className="border-b border-espresso/5 last:border-0 hover:bg-white/40 transition-colors">
                  <td className="px-6 py-4 text-sm text-espresso font-medium">{t.event}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 text-xs rounded-full ${
                      t.type === 'income' ? 'bg-green-100 text-green-600' :
                      t.type === 'fee' ? 'bg-red-100 text-red-500' :
                      'bg-amber-100 text-amber-600'
                    }`}>
                      {t.type === 'income' ? 'Venda' : t.type === 'fee' ? 'Taxa' : 'Reembolso'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-espresso/50">{t.date}</td>
                  <td className={`px-6 py-4 text-sm font-medium text-right ${t.amount > 0 ? 'text-green-600' : 'text-red-500'}`}>
                    {t.amount > 0 ? '+' : ''}R$ {Math.abs(t.amount).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
