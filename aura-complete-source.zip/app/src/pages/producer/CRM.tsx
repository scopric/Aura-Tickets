import { useState, useRef, useEffect } from 'react'
import {
  Users, Search, Download, Mail, Phone, MessageSquare, Calendar,
  CheckCircle2, XCircle, Plus, MoreHorizontal, Eye, Edit3, Send, Activity,
  BarChart3, PieChart, DollarSign, Percent, Sparkles, MapPin, Layers, Bookmark, Star
} from 'lucide-react'
import { crmLeads, pipelineStages } from '../../data/mockData'
import type { CRMLead } from '../../data/mockData'
import gsap from 'gsap'

/* ─── Score Ring ─── */
function ScoreRing({ score }: { score: number }) {
  const color = score >= 80 ? '#22c55e' : score >= 60 ? '#f59e0b' : score >= 40 ? '#f97316' : '#ef4444'
  return (
    <div className="relative w-10 h-10 flex-shrink-0">
      <svg className="w-10 h-10 -rotate-90" viewBox="0 0 40 40">
        <circle cx="20" cy="20" r="16" fill="none" stroke="#f0ebe3" strokeWidth="3" />
        <circle cx="20" cy="20" r="16" fill="none" stroke={color} strokeWidth="3" strokeDasharray={`${score * 1.005} 100.5`} strokeLinecap="round" />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold" style={{ color }}>{score}</span>
    </div>
  )
}

/* ─── Status Badge ─── */
function StatusBadge({ status }: { status: CRMLead['status'] }) {
  const map: Record<string, string> = {
    novo: 'bg-blue-50 text-blue-600 border-blue-100',
    qualificado: 'bg-violet-50 text-violet-600 border-violet-100',
    proposta: 'bg-amber-50 text-amber-600 border-amber-100',
    negociacao: 'bg-pink-50 text-pink-600 border-pink-100',
    fechado: 'bg-green-50 text-green-600 border-green-100',
    perdido: 'bg-red-50 text-red-500 border-red-100',
  }
  return (
    <span className={`px-2 py-0.5 text-[10px] font-medium rounded-full border ${map[status] || map.novo}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}

/* ─── Source Icon ─── */
function SourceIcon({ source }: { source: CRMLead['source'] }) {
  const labels: Record<string, string> = { instagram: 'IG', tiktok: 'TT', google: 'G', orgânico: 'Org', indicacao: 'Ind', evento: 'Evt' }
  return (
    <span className="w-6 h-6 rounded-md bg-canvas flex items-center justify-center text-[9px] font-bold text-espresso/40 border border-espresso/10">
      {labels[source] || source.slice(0, 2).toUpperCase()}
    </span>
  )
}

/* ─── Dashboard View ─── */
function DashboardView({ leads }: { leads: CRMLead[] }) {
  const total = leads.length
  const totalVal = leads.reduce((s, l) => s + l.value, 0)
  const avgScore = Math.round(leads.reduce((s, l) => s + l.score, 0) / total)
  const converted = leads.filter(l => l.status === 'fechado').length
  const convRate = Math.round((converted / total) * 100)
  const bySource = [...new Set(leads.map(l => l.source))].map(s => ({
    source: s, count: leads.filter(l => l.source === s).length,
    value: leads.filter(l => l.source === s).reduce((sum, l) => sum + l.value, 0)
  }))
  const byStatus = pipelineStages.map(p => ({
    ...p, count: leads.filter(l => l.status === p.id).length,
    value: leads.filter(l => l.status === p.id).reduce((s, l) => s + l.value, 0)
  }))

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total de Leads', value: total.toString(), icon: Users, change: '+12%', up: true },
          { label: 'Receita Potencial', value: `R$ ${(totalVal / 1000).toFixed(1)}K`, icon: DollarSign, change: '+18%', up: true },
          { label: 'Score Medio', value: `${avgScore}%`, icon: Star, change: '+5%', up: true },
          { label: 'Taxa de Conversao', value: `${convRate}%`, icon: Percent, change: '-2%', up: false },
        ].map(k => (
          <div key={k.label} className="p-5 rounded-2xl bg-white/60 border border-white/60 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <k.icon className="w-4 h-4 text-plum" />
              <span className={`text-[10px] font-medium ${k.up ? 'text-green-600' : 'text-red-500'}`}>{k.change}</span>
            </div>
            <div className="font-serif text-2xl text-espresso">{k.value}</div>
            <div className="text-[10px] text-espresso/40 mt-1 uppercase tracking-wider">{k.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Funnel */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-white/60 border border-white/60">
          <h3 className="text-sm font-medium text-espresso mb-6 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-plum" /> Funil de Conversao</h3>
          <div className="space-y-3">
            {byStatus.map(s => {
              const maxVal = Math.max(...byStatus.map(x => x.value || 1))
              const pct = ((s.value || 0) / maxVal) * 100
              return (
                <div key={s.id} className="flex items-center gap-3">
                  <span className="text-[11px] text-espresso/50 w-24 text-right truncate">{s.label}</span>
                  <div className="flex-1 h-7 bg-canvas rounded-lg overflow-hidden relative">
                    <div className="h-full rounded-lg transition-all duration-700 flex items-center px-3" style={{ width: `${Math.max(pct, 6)}%`, backgroundColor: `${s.color}15`, borderLeft: `3px solid ${s.color}` }}>
                      <span className="text-[11px] font-medium" style={{ color: s.color }}>{s.count}</span>
                    </div>
                  </div>
                  <span className="text-[11px] text-espresso/30 w-14 text-right">R$ {s.value.toLocaleString()}</span>
                </div>
              )
            })}
          </div>
        </div>

        {/* Source */}
        <div className="p-6 rounded-2xl bg-white/60 border border-white/60">
          <h3 className="text-sm font-medium text-espresso mb-4 flex items-center gap-2"><PieChart className="w-4 h-4 text-plum" /> Origem dos Leads</h3>
          <div className="space-y-3">
            {bySource.map(s => (
              <div key={s.source} className="flex items-center gap-3">
                <SourceIcon source={s.source} />
                <div className="flex-1">
                  <div className="flex justify-between mb-1"><span className="text-[11px] text-espresso/60 capitalize">{s.source}</span><span className="text-[11px] text-espresso/40">{s.count}</span></div>
                  <div className="w-full h-1.5 bg-canvas rounded-full overflow-hidden"><div className="h-full bg-plum rounded-full" style={{ width: `${(s.count / total) * 100}%` }} /></div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-4 border-t border-espresso/5">
            <h4 className="text-[10px] text-espresso/30 uppercase tracking-wider mb-3">Top Tags</h4>
            <div className="flex flex-wrap gap-1.5">
              {['VIP', 'Mesa Coletiva', 'Grupo', 'Recorrente', 'Influencer', 'Primeira Compra'].map(tag => {
                const count = leads.filter(l => l.tags.includes(tag)).length
                return <span key={tag} className="px-2 py-1 bg-canvas text-espresso/50 text-[10px] rounded-md border border-espresso/5">{tag} ({count})</span>
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Recent */}
      <div className="p-6 rounded-2xl bg-white/60 border border-white/60">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-espresso flex items-center gap-2"><Activity className="w-4 h-4 text-plum" /> Atividade Recente</h3>
          <span className="text-[10px] text-espresso/30">Ver todas</span>
        </div>
        <div className="divide-y divide-espresso/5">
          {leads.slice(0, 5).map(l => (
            <div key={l.id} className="flex items-center gap-4 py-3 hover:bg-white/40 transition-colors -mx-2 px-2 rounded-lg">
              <img src={l.avatar} alt="" className="w-9 h-9 rounded-full object-cover ring-2 ring-canvas" />
              <div className="flex-1 min-w-0">
                <div className="text-sm text-espresso font-medium">{l.name}</div>
                <div className="text-[10px] text-espresso/30">{l.lastActivity} · {l.eventInterest}</div>
              </div>
              <ScoreRing score={l.score} />
              <StatusBadge status={l.status} />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ─── Pipeline View ─── */
function PipelineView({ leads }: { leads: CRMLead[] }) {
  const stages = pipelineStages.map(p => ({ ...p, items: leads.filter(l => l.status === p.id) }))

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-espresso/60 flex items-center gap-2"><Layers className="w-4 h-4 text-plum" /> Pipeline Visual</h3>
        <button className="flex items-center gap-2 px-4 py-2 bg-plum text-cream text-xs font-medium rounded-full hover:shadow-glow transition-all"><Plus className="w-3.5 h-3.5" /> Novo Lead</button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {stages.map(stage => (
          <div key={stage.id} className="bg-white/40 rounded-2xl border border-white/60 flex flex-col">
            <div className="p-3 border-b border-espresso/5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: stage.color }} />
                <span className="text-[11px] font-medium text-espresso/70">{stage.label}</span>
              </div>
              <span className="text-[10px] text-espresso/30 px-1.5 py-0.5 bg-canvas rounded-md">{stage.items.length}</span>
            </div>
            <div className="p-2 space-y-2 flex-1">
              {stage.items.map(lead => (
                <div key={lead.id} className="p-3 rounded-xl bg-white/60 border border-white/60 hover:border-plum/20 hover:shadow-sm transition-all group cursor-pointer">
                  <div className="flex items-center gap-2 mb-2">
                    <img src={lead.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                    <div className="flex-1 min-w-0"><div className="text-[11px] text-espresso font-medium truncate">{lead.name}</div></div>
                    <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-canvas rounded"><MoreHorizontal className="w-3 h-3 text-espresso/30" /></button>
                  </div>
                  {lead.value > 0 && <div className="text-[11px] font-serif text-espresso/60 mb-1.5">R$ {lead.value}</div>}
                  <div className="flex items-center gap-1 flex-wrap">
                    {lead.tags.slice(0, 2).map(tag => <span key={tag} className="px-1.5 py-0.5 bg-canvas text-espresso/30 text-[9px] rounded">{tag}</span>)}
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-[9px] text-espresso/20">{lead.lastActivity}</span>
                    <ScoreRing score={lead.score} />
                  </div>
                </div>
              ))}
              {stage.items.length === 0 && <div className="py-8 text-center"><span className="text-[10px] text-espresso/15">Vazio</span></div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ─── Leads List View ─── */
function LeadsListView({ leads }: { leads: CRMLead[] }) {
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [selectedLead, setSelectedLead] = useState<CRMLead | null>(null)
  const [sortBy, setSortBy] = useState<'score' | 'value' | 'recent'>('score')

  const filtered = leads
    .filter(l => (l.name.toLowerCase().includes(search.toLowerCase()) || l.email.toLowerCase().includes(search.toLowerCase())) && (filterStatus === 'all' || l.status === filterStatus))
    .sort((a, b) => sortBy === 'score' ? b.score - a.score : sortBy === 'value' ? b.value - a.value : 0)

  return (
    <>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-espresso/20" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nome ou email..." className="w-full pl-10 pr-4 py-2.5 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30" />
          </div>
          <div className="flex items-center gap-2">
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="px-3 py-2.5 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso/60 focus:outline-none">
              <option value="all">Todos</option>
              {pipelineStages.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}
            </select>
            <select value={sortBy} onChange={e => setSortBy(e.target.value as typeof sortBy)} className="px-3 py-2.5 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso/60 focus:outline-none">
              <option value="score">Score</option>
              <option value="value">Valor</option>
              <option value="recent">Recente</option>
            </select>
            <button className="p-2.5 bg-white/60 border border-white/60 rounded-xl text-espresso/30 hover:text-espresso/60 transition-colors"><Download className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="bg-white/60 border border-white/60 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-espresso/5">
                  <th className="text-left px-4 py-3 text-[10px] font-medium text-espresso/30 uppercase">Lead</th>
                  <th className="text-left px-4 py-3 text-[10px] font-medium text-espresso/30 uppercase hidden lg:table-cell">Origem</th>
                  <th className="text-left px-4 py-3 text-[10px] font-medium text-espresso/30 uppercase">Status</th>
                  <th className="text-left px-4 py-3 text-[10px] font-medium text-espresso/30 uppercase hidden md:table-cell">Score</th>
                  <th className="text-right px-4 py-3 text-[10px] font-medium text-espresso/30 uppercase">Valor</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(lead => (
                  <tr key={lead.id} className="border-b border-espresso/3 last:border-0 hover:bg-white/40 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img src={lead.avatar} alt="" className="w-8 h-8 rounded-full object-cover ring-2 ring-canvas" />
                        <div>
                          <div className="text-sm text-espresso font-medium">{lead.name}</div>
                          <div className="text-[10px] text-espresso/30">{lead.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <div className="flex items-center gap-2"><SourceIcon source={lead.source} /><span className="text-xs text-espresso/40 capitalize">{lead.source}</span></div>
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={lead.status} /></td>
                    <td className="px-4 py-3 hidden md:table-cell"><ScoreRing score={lead.score} /></td>
                    <td className="px-4 py-3 text-right text-sm text-espresso font-serif">{lead.value > 0 ? `R$ ${lead.value}` : '-'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setSelectedLead(lead)} className="p-1.5 rounded-lg hover:bg-canvas text-espresso/20 hover:text-espresso/60 transition-colors"><Eye className="w-3.5 h-3.5" /></button>
                        <button className="p-1.5 rounded-lg hover:bg-canvas text-espresso/20 hover:text-espresso/60 transition-colors"><Edit3 className="w-3.5 h-3.5" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Detail Drawer */}
      {selectedLead && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setSelectedLead(null)} />
          <div className="relative w-full max-w-md bg-canvas border-l border-espresso/10 h-full overflow-y-auto shadow-2xl">
            <div className="p-6">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-3">
                  <img src={selectedLead.avatar} alt="" className="w-14 h-14 rounded-full object-cover ring-2 ring-plum/30" />
                  <div>
                    <h3 className="font-serif text-xl text-espresso">{selectedLead.name}</h3>
                    <div className="flex items-center gap-2 mt-1"><StatusBadge status={selectedLead.status} /><span className="text-[10px] text-espresso/30">Score {selectedLead.score}</span></div>
                  </div>
                </div>
                <button onClick={() => setSelectedLead(null)} className="p-2 rounded-full bg-canvas text-espresso/40 hover:text-espresso transition-colors"><XCircle className="w-5 h-5" /></button>
              </div>

              <div className="space-y-2 mb-6">
                <div className="flex items-center gap-2 text-sm text-espresso/50"><Mail className="w-4 h-4 text-espresso/30" />{selectedLead.email}</div>
                <div className="flex items-center gap-2 text-sm text-espresso/50"><Phone className="w-4 h-4 text-espresso/30" />{selectedLead.phone}</div>
                <div className="flex items-center gap-2 text-sm text-espresso/50"><MapPin className="w-4 h-4 text-espresso/30" />{selectedLead.assignedTo}</div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="p-4 rounded-xl bg-white/60 border border-white/60 text-center"><ScoreRing score={selectedLead.score} /><div className="text-[10px] text-espresso/30 mt-2">Score</div></div>
                <div className="p-4 rounded-xl bg-white/60 border border-white/60 text-center"><div className="font-serif text-2xl text-espresso">R$ {selectedLead.value}</div><div className="text-[10px] text-espresso/30 mt-1">Valor</div></div>
              </div>

              <div className="flex flex-wrap gap-1.5 mb-6">
                {selectedLead.tags.map(tag => <span key={tag} className="px-2.5 py-1 bg-plum/10 text-plum text-[11px] rounded-full border border-plum/20">{tag}</span>)}
              </div>

              <div className="p-4 rounded-xl bg-white/60 border border-white/60 mb-6">
                <h4 className="text-xs font-medium text-espresso/60 mb-2 flex items-center gap-1"><Bookmark className="w-3 h-3" /> Notas</h4>
                <p className="text-sm text-espresso/40 leading-relaxed">{selectedLead.notes}</p>
              </div>

              <div className="mb-6">
                <h4 className="text-xs font-medium text-espresso/60 mb-3 flex items-center gap-1"><Activity className="w-3 h-3" /> Historico</h4>
                <div className="space-y-3">
                  {selectedLead.interactions.map((inter, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-7 h-7 rounded-full bg-plum/10 flex items-center justify-center flex-shrink-0">
                        {inter.type === 'email' ? <Mail className="w-3 h-3 text-plum" /> : inter.type === 'whatsapp' ? <MessageSquare className="w-3 h-3 text-plum" /> : inter.type === 'call' ? <Phone className="w-3 h-3 text-plum" /> : <Calendar className="w-3 h-3 text-plum" />}
                      </div>
                      <div>
                        <div className="text-[11px] text-espresso/60">{inter.content}</div>
                        <div className="text-[10px] text-espresso/25">{inter.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-xs font-medium text-espresso/60 mb-3 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Tarefas</h4>
                <div className="space-y-2">
                  {selectedLead.tasks.map(task => (
                    <div key={task.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/60 border border-white/60">
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${task.done ? 'bg-green-500 border-green-500' : 'border-espresso/20'}`}>
                        {task.done && <CheckCircle2 className="w-3 h-3 text-white" />}
                      </div>
                      <span className={`text-[11px] flex-1 ${task.done ? 'text-espresso/30 line-through' : 'text-espresso/60'}`}>{task.title}</span>
                      <span className="text-[10px] text-espresso/20">{task.due}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-br from-plum/5 to-transparent border border-plum/10 mb-6">
                <h4 className="text-xs font-medium text-espresso/60 mb-2 flex items-center gap-1"><Sparkles className="w-3 h-3 text-plum" /> Matchmaking Social</h4>
                <div className="flex items-center gap-6 text-sm">
                  <div><div className="text-[10px] text-espresso/30">Temperamento</div><div className="text-espresso/70 capitalize">{selectedLead.temperament}</div></div>
                  <div><div className="text-[10px] text-espresso/30">Intencao</div><div className="text-espresso/70 capitalize">{selectedLead.intent}</div></div>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 py-2.5 bg-plum text-cream text-xs font-medium rounded-full hover:shadow-glow transition-all flex items-center justify-center gap-1.5"><Send className="w-3.5 h-3.5" /> Mensagem</button>
                <button className="flex-1 py-2.5 bg-canvas text-espresso text-xs font-medium rounded-full hover:bg-white transition-all flex items-center justify-center gap-1.5 border border-espresso/10"><Phone className="w-3.5 h-3.5" /> Ligar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

/* ─── Comunicacao View ─── */
function ComunicacaoView({ leads }: { leads: CRMLead[] }) {
  const [selectedLead, setSelectedLead] = useState<CRMLead | null>(leads[0])
  const [msg, setMsg] = useState('')

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[600px]">
      <div className="lg:col-span-1 bg-white/40 rounded-2xl border border-white/60 overflow-hidden flex flex-col">
        <div className="p-3 border-b border-espresso/5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-espresso/20" />
            <input placeholder="Buscar..." className="w-full pl-9 pr-3 py-2 bg-white/60 border border-white/60 rounded-xl text-xs text-espresso placeholder:text-espresso/20 focus:outline-none" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {leads.map(l => (
            <button key={l.id} onClick={() => setSelectedLead(l)} className={`w-full flex items-center gap-3 p-2.5 rounded-xl transition-all text-left ${selectedLead?.id === l.id ? 'bg-plum/10 border border-plum/20' : 'hover:bg-white/40 border border-transparent'}`}>
              <img src={l.avatar} alt="" className="w-8 h-8 rounded-full object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-xs text-espresso font-medium truncate">{l.name}</div>
                <div className="text-[10px] text-espresso/30 truncate">{l.interactions[0]?.content || 'Nenhuma'}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-2 bg-white/40 rounded-2xl border border-white/60 flex flex-col overflow-hidden">
        {selectedLead ? (
          <>
            <div className="p-4 border-b border-espresso/5 flex items-center gap-3">
              <img src={selectedLead.avatar} alt="" className="w-9 h-9 rounded-full object-cover" />
              <div className="flex-1">
                <div className="text-sm text-espresso font-medium">{selectedLead.name}</div>
                <div className="text-[10px] text-espresso/30">{selectedLead.email}</div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 rounded-lg hover:bg-canvas text-espresso/30 hover:text-espresso/60 transition-colors"><Phone className="w-4 h-4" /></button>
                <button className="p-2 rounded-lg hover:bg-canvas text-espresso/30 hover:text-espresso/60 transition-colors"><Mail className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {selectedLead.interactions.map((inter, i) => (
                <div key={i} className={`flex ${inter.type === 'event' || inter.type === 'email' ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl ${inter.type === 'event' || inter.type === 'email' ? 'bg-white/60 text-espresso/70 rounded-bl-md border border-white/60' : 'bg-plum text-cream rounded-br-md'}`}>
                    <p className="text-[12px] leading-relaxed">{inter.content}</p>
                    <span className="text-[9px] mt-1 block opacity-50">{inter.date}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-espresso/5">
              <div className="flex items-center gap-2">
                <input value={msg} onChange={e => setMsg(e.target.value)} placeholder="Escreva..." className="flex-1 px-4 py-2.5 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/20 focus:outline-none" />
                <button className="p-2.5 bg-plum text-cream rounded-xl hover:shadow-glow transition-all"><Send className="w-4 h-4" /></button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-espresso/20 text-sm">Selecione um lead</div>
        )}
      </div>
    </div>
  )
}

/* ─── Main Page ─── */
export default function ProducerCRM() {
  const [activeView, setActiveView] = useState<'dashboard' | 'pipeline' | 'leads' | 'comunicacao'>('dashboard')
  const ref = useRef<HTMLDivElement>(null)
  const leads = crmLeads

  useEffect(() => {
    if (!ref.current) return
    gsap.fromTo('.crm-content', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power3.out' })
  }, [activeView])

  const views = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: BarChart3 },
    { id: 'pipeline' as const, label: 'Pipeline', icon: Layers },
    { id: 'leads' as const, label: 'Leads', icon: Users },
    { id: 'comunicacao' as const, label: 'Comunicacao', icon: MessageSquare },
  ]

  const activeCount = {
    dashboard: leads.length,
    pipeline: leads.filter(l => ['novo', 'qualificado', 'proposta', 'negociacao'].includes(l.status)).length,
    leads: leads.length,
    comunicacao: leads.filter(l => l.interactions.length > 0).length,
  }

  return (
    <div ref={ref} className="p-6 lg:p-10 max-w-[1400px]">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-serif text-3xl text-espresso">CRM</h1>
          <p className="text-sm text-espresso/50 mt-1">Gestao completa de leads e comunicacao</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 bg-white/60 border border-white/60 text-espresso text-sm font-medium rounded-full hover:bg-white transition-all">
            <Download className="w-4 h-4" /> Exportar
          </button>
          <button className="flex items-center gap-2 px-5 py-2.5 bg-plum text-cream text-sm font-medium rounded-full hover:shadow-glow transition-all">
            <Plus className="w-4 h-4" /> Novo Lead
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-white/60 border border-white/60 rounded-2xl mb-8 w-fit">
        {views.map(v => (
          <button key={v.id} onClick={() => setActiveView(v.id)} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${activeView === v.id ? 'bg-plum text-cream shadow-lg shadow-plum/20' : 'text-espresso/40 hover:text-espresso/70 hover:bg-white/60'}`}>
            <v.icon className="w-4 h-4" />
            {v.label}
            <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${activeView === v.id ? 'bg-cream/20' : 'bg-canvas'}`}>{activeCount[v.id]}</span>
          </button>
        ))}
      </div>

      <div className="crm-content">
        {activeView === 'dashboard' && <DashboardView leads={leads} />}
        {activeView === 'pipeline' && <PipelineView leads={leads} />}
        {activeView === 'leads' && <LeadsListView leads={leads} />}
        {activeView === 'comunicacao' && <ComunicacaoView leads={leads} />}
      </div>
    </div>
  )
}
