import { useState } from 'react'
import { Link } from 'react-router'
import { Eye, EyeOff, ArrowRight, Users, Shield, PartyPopper } from 'lucide-react'

type UserRole = 'user' | 'producer' | 'admin'

export default function AuthLogin() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<UserRole>('user')

  const roles: { value: UserRole; label: string; icon: typeof Users; desc: string; color: string; path: string }[] = [
    { value: 'user', label: 'Participante', icon: Users, desc: 'Comprar ingressos e viver experiencias', color: 'plum', path: '/app/hub' },
    { value: 'producer', label: 'Produtor', icon: PartyPopper, desc: 'Criar e gerenciar seus eventos', color: 'amber', path: '/producer/dashboard' },
    { value: 'admin', label: 'Administrador', icon: Shield, desc: 'Gestao interna da plataforma', color: 'rose', path: '/admin/dashboard' },
  ]

  const currentRole = roles.find(r => r.value === role)!

  return (
    <div className="min-h-screen bg-canvas flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <img src="/images/logo-aura.png" alt="Aura" className="h-10 w-auto" />
          </Link>
          <h1 className="font-serif text-2xl text-espresso">Bem-vindo de volta</h1>
          <p className="text-sm text-espresso/50 mt-1">Escolha seu perfil e entre</p>
        </div>

        {/* Role Selection */}
        <div className="bg-white/60 border border-white/60 rounded-2xl p-1.5 mb-6 flex gap-1">
          {roles.map((r) => (
            <button
              key={r.value}
              onClick={() => setRole(r.value)}
              className={`flex-1 py-2.5 px-2 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
                role === r.value
                  ? r.value === 'admin'
                    ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20'
                    : r.value === 'producer'
                    ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20'
                    : 'bg-plum text-cream shadow-lg shadow-plum/20'
                  : 'text-espresso/40 hover:text-espresso/70'
              }`}
            >
              <r.icon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{r.label}</span>
            </button>
          ))}
        </div>

        {/* Role description */}
        <div className={`p-4 rounded-2xl mb-6 text-center ${
          role === 'admin' ? 'bg-rose-50 border border-rose-100' :
          role === 'producer' ? 'bg-amber-50 border border-amber-100' :
          'bg-plum/5 border border-plum/10'
        }`}>
          <p className={`text-sm ${
            role === 'admin' ? 'text-rose-700' :
            role === 'producer' ? 'text-amber-700' :
            'text-plum'
          }`}>{currentRole.desc}</p>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-espresso/60 mb-1.5 block">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="w-full px-4 py-3 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-espresso/60 mb-1.5 block">Senha</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Sua senha"
                className="w-full px-4 py-3 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30 transition-colors pr-10"
              />
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-espresso/30 hover:text-espresso transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-xs text-espresso/50 cursor-pointer">
              <input type="checkbox" className="accent-plum" />
              Lembrar-me
            </label>
            <button className="text-xs text-plum hover:underline">Esqueci a senha</button>
          </div>

          <Link
            to={currentRole.path}
            className={`w-full py-3 font-medium rounded-full transition-all flex items-center justify-center gap-2 ${
              role === 'admin' ? 'bg-rose-500 text-white hover:shadow-lg hover:shadow-rose-500/20' :
              role === 'producer' ? 'bg-amber-500 text-white hover:shadow-lg hover:shadow-amber-500/20' :
              'bg-plum text-cream hover:shadow-glow'
            }`}
          >
            Entrar como {currentRole.label}
            <ArrowRight className="w-4 h-4" />
          </Link>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-espresso/5" />
            </div>
            <div className="relative flex justify-center">
              <span className="px-3 bg-canvas text-xs text-espresso/30">ou</span>
            </div>
          </div>

          <button className="w-full py-3 border border-espresso/15 text-espresso text-sm font-medium rounded-full hover:bg-espresso/5 transition-all">
            Entrar com Google
          </button>
        </div>

        <p className="text-center text-xs text-espresso/40 mt-6">
          Nao tem conta?{' '}
          <Link to="/auth/register" className="text-plum hover:underline">Criar conta</Link>
        </p>

        {/* App download hint */}
        <div className="mt-8 p-4 rounded-2xl bg-void text-cream text-center">
          <p className="text-xs text-cream/50 mb-2">Baixe o app para uma experiencia completa</p>
          <Link
            to="/app/download"
            className="text-xs text-plum hover:text-cream transition-colors inline-flex items-center gap-1"
          >
            Ver opcoes de download <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    </div>
  )
}
