import { useState } from 'react'
import { Link } from 'react-router'
import { Eye, EyeOff, ArrowRight, User, Building } from 'lucide-react'

export default function AuthRegister() {
  const [showPassword, setShowPassword] = useState(false)
  const [type, setType] = useState<'producer' | 'attendee'>('producer')

  return (
    <div className="min-h-screen bg-canvas flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <img src="/images/logo-aura.png" alt="Aura" className="h-10 w-auto" />
          </Link>
          <h1 className="font-serif text-2xl text-espresso">Criar conta</h1>
          <p className="text-sm text-espresso/50 mt-1">Comece a criar eventos</p>
        </div>

        {/* Type Toggle */}
        <div className="flex items-center bg-white/60 border border-white/60 rounded-full p-1 mb-6">
          <button onClick={() => setType('producer')} className={`flex-1 py-2 text-xs font-medium rounded-full transition-all flex items-center justify-center gap-1.5 ${type === 'producer' ? 'bg-plum text-cream' : 'text-espresso/50'}`}>
            <Building className="w-3.5 h-3.5" />
            Produtor
          </button>
          <button onClick={() => setType('attendee')} className={`flex-1 py-2 text-xs font-medium rounded-full transition-all flex items-center justify-center gap-1.5 ${type === 'attendee' ? 'bg-plum text-cream' : 'text-espresso/50'}`}>
            <User className="w-3.5 h-3.5" />
            Participante
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-espresso/60 mb-1.5 block">Nome</label>
              <input type="text" placeholder="Seu nome" className="w-full px-4 py-3 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30" />
            </div>
            <div>
              <label className="text-xs font-medium text-espresso/60 mb-1.5 block">Sobrenome</label>
              <input type="text" placeholder="Sobrenome" className="w-full px-4 py-3 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30" />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-espresso/60 mb-1.5 block">E-mail</label>
            <input type="email" placeholder="seu@email.com" className="w-full px-4 py-3 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30" />
          </div>
          <div>
            <label className="text-xs font-medium text-espresso/60 mb-1.5 block">Senha</label>
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} placeholder="Minimo 8 caracteres" className="w-full px-4 py-3 bg-white/60 border border-white/60 rounded-xl text-sm text-espresso placeholder:text-espresso/30 focus:outline-none focus:border-plum/30 pr-10" />
              <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-espresso/30 hover:text-espresso transition-colors">
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button className="w-full py-3 bg-plum text-cream font-medium rounded-full hover:shadow-glow transition-all flex items-center justify-center gap-2">
            Criar Conta
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <p className="text-center text-xs text-espresso/40 mt-6">
          Ja tem conta?{' '}
          <Link to="/auth/login" className="text-plum hover:underline">Entrar</Link>
        </p>
      </div>
    </div>
  )
}
