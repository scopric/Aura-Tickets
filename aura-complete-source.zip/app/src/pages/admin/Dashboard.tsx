import { useState } from 'react'
import { Users, Calendar, DollarSign, Ticket, Shield, Activity, Zap } from 'lucide-react'

export default function AdminDashboard() {
  const [period, setPeriod] = useState('month')

  const stats = [
    { label: 'Usuarios', value: '12.847', change: '+8%', icon: Users, color: 'blue' },
    { label: 'Eventos Ativos', value: '342', change: '+12%', icon: Calendar, color: 'green' },
    { label: 'Receita Total', value: 'R$ 1.2M', change: '+15%', icon: DollarSign, color: 'plum' },
    { label: 'Ingressos', value: '89.420', change: '+10%', icon: Ticket, color: 'amber' },
  ]

  const recentEvents = [
    { id: '1', name: 'Noite Eletro 2025', producer: 'Joao Silva', revenue: 'R$ 45.680', status: 'active' },
    { id: '2', name: 'Jazz Sunset Session', producer: 'Maria Costa', revenue: 'R$ 12.340', status: 'active' },
    { id: '3', name: 'Feira de Arte', producer: 'Pedro Oliveira', revenue: 'R$ 8.920', status: 'active' },
    { id: '4', name: 'Festival de Inverno', producer: 'Ana Souza', revenue: 'R$ 67.000', status: 'upcoming' },
  ]

  const topProducers = [
    { name: 'Joao Silva', events: 12, revenue: 'R$ 156K', growth: '+23%' },
    { name: 'Maria Costa', events: 8, revenue: 'R$ 98K', growth: '+18%' },
    { name: 'Pedro Oliveira', events: 6, revenue: 'R$ 72K', growth: '+15%' },
  ]

  return (
    <div className="p-6 lg:p-10 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-serif text-3xl text-espresso">Painel Administrativo</h1>
          <p className="text-sm text-espresso/50 mt-1">Visao geral da plataforma Aura</p>
        </div>
        <div className="flex items-center bg-white/60 border border-white/60 rounded-full p-1">
          {['week', 'month', 'year'].map(p => (
            <button key={p} onClick={() => setPeriod(p)} className={`px-4 py-1.5 text-xs font-medium rounded-full transition-all ${period === p ? 'bg-rose-500 text-white' : 'text-espresso/50 hover:text-espresso'}`}>
              {p === 'week' ? 'Semana' : p === 'month' ? 'Mes' : 'Ano'}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="p-5 rounded-2xl bg-white/60 border border-white/60 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <s.icon className="w-5 h-5 text-rose-500" />
              <span className="text-xs font-medium text-green-600">{s.change}</span>
            </div>
            <div className="font-serif text-2xl text-espresso">{s.value}</div>
            <div className="text-xs text-espresso/40 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-white/60 border border-white/60 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-serif text-xl text-espresso">Faturamento da Plataforma</h2>
            <span className="text-xs text-espresso/40">Fee medio: 5% por transacao</span>
          </div>
          <div className="h-48 flex items-end gap-2">
            {[25, 40, 35, 55, 45, 70, 60, 80, 65, 85, 75, 95].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full rounded-t-lg bg-rose-500/20 hover:bg-rose-500/40 transition-colors" style={{ height: `${h * 1.8}px` }} />
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-3">
            {['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'].map(m => (
              <span key={m} className="flex-1 text-center text-[10px] text-espresso/30">{m}</span>
            ))}
          </div>
        </div>

        {/* Top Producers */}
        <div className="p-6 rounded-2xl bg-white/60 border border-white/60 backdrop-blur-sm">
          <h2 className="font-serif text-xl text-espresso mb-4">Top Produtores</h2>
          <div className="space-y-4">
            {topProducers.map((p, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/40">
                <div className="w-8 h-8 rounded-full bg-rose-500/10 flex items-center justify-center text-xs font-medium text-rose-500">{i + 1}</div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-espresso">{p.name}</div>
                  <div className="text-xs text-espresso/40">{p.events} eventos</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-espresso">{p.revenue}</div>
                  <div className="text-xs text-green-600">{p.growth}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Events */}
      <div className="mt-6 bg-white/60 border border-white/60 rounded-2xl overflow-hidden backdrop-blur-sm">
        <div className="p-6 border-b border-espresso/5 flex items-center justify-between">
          <h2 className="font-serif text-xl text-espresso">Eventos Recentes</h2>
          <button className="text-xs text-rose-500 hover:underline">Ver todos</button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-espresso/5">
              <th className="text-left px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Evento</th>
              <th className="text-left px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Produtor</th>
              <th className="text-left px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Status</th>
              <th className="text-right px-6 py-4 text-xs font-medium text-espresso/40 uppercase">Receita</th>
            </tr>
          </thead>
          <tbody>
            {recentEvents.map(e => (
              <tr key={e.id} className="border-b border-espresso/5 last:border-0 hover:bg-white/40 transition-colors">
                <td className="px-6 py-4 text-sm font-medium text-espresso">{e.name}</td>
                <td className="px-6 py-4 text-sm text-espresso/60">{e.producer}</td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 text-xs rounded-full ${e.status === 'active' ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'}`}>
                    {e.status === 'active' ? 'Ativo' : 'Em breve'}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm font-medium text-espresso text-right">{e.revenue}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Quick Actions */}
      <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Usuarios', icon: Users, desc: '12.847 cadastrados' },
          { label: 'Produtores', icon: Shield, desc: '342 ativos' },
          { label: 'Transacoes', icon: Activity, desc: '8.920 este mes' },
          { label: 'Taxa de Fee', icon: Zap, desc: '5% por transacao' },
        ].map(a => (
          <div key={a.label} className="p-4 rounded-2xl bg-void text-cream hover:bg-void/80 transition-colors cursor-pointer">
            <a.icon className="w-5 h-5 text-rose-500 mb-2" />
            <div className="text-sm font-medium">{a.label}</div>
            <div className="text-xs text-cream/40">{a.desc}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
