import { Link } from 'react-router'
import { ArrowRight, Zap, Users, BarChart3, Palette, Ticket, Shield } from 'lucide-react'
import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import VideoHero from '../components/VideoHero'

gsap.registerPlugin(ScrollTrigger)

export default function Home() {
  const featuresRef = useRef<HTMLDivElement>(null)
  const statsRef = useRef<HTMLDivElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Features animation
      gsap.fromTo('.feature-card',
        { y: 60, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.15, ease: 'power3.out',
          scrollTrigger: { trigger: featuresRef.current, start: 'top 80%', toggleActions: 'play none none none' }
        }
      )

      // Stats animation
      gsap.fromTo('.stat-item',
        { y: 40, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: 'power3.out',
          scrollTrigger: { trigger: statsRef.current, start: 'top 85%', toggleActions: 'play none none none' }
        }
      )

      // CTA animation
      gsap.fromTo('.cta-content',
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 1, ease: 'power3.out',
          scrollTrigger: { trigger: ctaRef.current, start: 'top 80%', toggleActions: 'play none none none' }
        }
      )
    })

    return () => ctx.revert()
  }, [])

  const features = [
    {
      icon: Zap,
      title: 'Crie em Minutos',
      description: 'Configure seu evento com poucos cliques. Nossa interface intuitiva torna o processo simples e rápido.'
    },
    {
      icon: Ticket,
      title: 'Gestão de Ingressos',
      description: 'Múltiplos tipos de ingressos, controle de capacidade e vendas em tempo real integrados.'
    },
    {
      icon: Palette,
      title: 'Brand Studio',
      description: 'Personalize a página do seu evento com cores, fontes e estilos que combinam com sua marca.'
    },
    {
      icon: Users,
      title: 'Comprovação Social',
      description: 'Mostre quem está interessado e comprou ingressos. Crie urgência e desejo naturalmente.'
    },
    {
      icon: BarChart3,
      title: 'Analytics em Tempo Real',
      description: 'Acompanhe vendas, engajamento e métricas importantes em um dashboard elegante.'
    },
    {
      icon: Shield,
      title: 'Segurança Total',
      description: 'Pagamentos seguros, validação de ingressos e proteção contra fraudes integrados.'
    }
  ]

  const stats = [
    { value: '10K+', label: 'Eventos Criados' },
    { value: '500K+', label: 'Ingressos Vendidos' },
    { value: '98%', label: 'Satisfação' },
    { value: '50+', label: 'Países' }
  ]

  return (
    <div className="bg-canvas">
      {/* Video Hero with 3D Ticket */}
      <VideoHero />

      {/* Stats Section */}
      <section ref={statsRef} className="py-20 lg:py-32 border-y border-espresso/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {stats.map((stat) => (
              <div key={stat.label} className="stat-item text-center">
                <div className="font-serif text-4xl lg:text-5xl text-plum mb-2">{stat.value}</div>
                <div className="text-sm text-espresso/50 uppercase tracking-widest">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section ref={featuresRef} className="py-24 lg:py-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 lg:mb-24">
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-espresso mb-6">
              Tudo que Você <span className="italic text-plum">Precisa</span>
            </h2>
            <p className="text-espresso/60 text-lg max-w-2xl mx-auto">
              Ferramentas poderosas para criar experiências memoráveis, do início ao fim.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="feature-card group p-8 rounded-3xl bg-white/50 border border-white/60 backdrop-blur-sm transition-all duration-500 hover:shadow-elevated hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-2xl bg-plum/10 flex items-center justify-center mb-6 transition-all duration-300 group-hover:bg-plum group-hover:shadow-glow">
                  <feature.icon className="w-5 h-5 text-plum transition-colors group-hover:text-cream" />
                </div>
                <h3 className="font-serif text-xl text-espresso mb-3">{feature.title}</h3>
                <p className="text-sm text-espresso/60 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 lg:py-40 bg-void text-cream relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-void via-void to-plum/20" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 lg:mb-24">
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl mb-6">
              Como <span className="italic text-plum">Funciona</span>
            </h2>
            <p className="text-cream/60 text-lg max-w-2xl mx-auto">
              Três passos simples para transformar sua visão em realidade.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            {[
              { step: '01', title: 'Crie Seu Evento', desc: 'Configure nome, data, local e descrição em minutos com nossa interface intuitiva.' },
              { step: '02', title: 'Personalize', desc: 'Use o Brand Studio para criar uma página única que reflita sua identidade visual.' },
              { step: '03', title: 'Publique & Venda', desc: 'Compartilhe o link e comece a vender ingressos imediatamente. Acompanhe tudo em tempo real.' }
            ].map((item) => (
              <div key={item.step} className="relative text-center">
                <div className="font-serif text-7xl text-plum/20 mb-4">{item.step}</div>
                <h3 className="font-serif text-2xl mb-4">{item.title}</h3>
                <p className="text-cream/50 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section ref={ctaRef} className="py-24 lg:py-40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="cta-content">
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-7xl text-espresso mb-8 leading-tight">
              Pronto para Criar
              <br />
              <span className="italic text-plum">Algo Extraordinário?</span>
            </h2>
            <p className="text-espresso/60 text-lg mb-12 max-w-xl mx-auto">
              Junte-se a milhares de criadores que já transformam experiências com a Aura.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/auth/register"
                className="group px-8 py-4 bg-plum text-cream font-medium rounded-full transition-all duration-300 hover:shadow-glow hover:scale-105 flex items-center gap-2"
              >
                Criar Meu Evento
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/producer/brand"
                className="px-8 py-4 border border-espresso/20 text-espresso font-medium rounded-full transition-all duration-300 hover:bg-espresso/5"
              >
                Explorar Brand Studio
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
