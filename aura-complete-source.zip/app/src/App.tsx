import { Routes, Route, useLocation } from 'react-router'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import EventPage from './pages/EventPage'
import BrandStudio from './pages/BrandStudio'
import ProducerLayout from './components/ProducerLayout'
import ProducerDashboard from './pages/producer/Dashboard'
import ProducerEvents from './pages/producer/Events'
import ProducerNewEvent from './pages/producer/NewEvent'
import ProducerCRM from './pages/producer/CRM'
import ProducerFinance from './pages/producer/Finance'
import ProducerWallet from './pages/producer/Wallet'
import ProducerMenu from './pages/producer/Menu'
import TableCalculator from './pages/producer/TableCalculator'
import AdminLayout from './components/AdminLayout'
import AdminDashboard from './pages/admin/Dashboard'
import Checkout from './pages/checkout/Checkout'
import CheckoutPayment from './pages/checkout/Payment'
import CheckoutSuccess from './pages/checkout/Success'
import AuthLogin from './pages/auth/Login'
import AuthRegister from './pages/auth/Register'
import AppHub from './pages/app/Hub'
import AppDownload from './pages/app/Download'

function Layout() {
  const location = useLocation()
  const hideLayout = location.pathname.startsWith('/producer') ||
    location.pathname.startsWith('/admin') ||
    location.pathname.startsWith('/auth') ||
    location.pathname.startsWith('/checkout')

  return (
    <div className="min-h-screen bg-canvas">
      {!hideLayout && <Header />}
      <main>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Home />} />
          <Route path="/event/:eventId" element={<EventPage />} />

          {/* Auth */}
          <Route path="/auth/login" element={<AuthLogin />} />
          <Route path="/auth/register" element={<AuthRegister />} />

          {/* App */}
          <Route path="/app/hub" element={<AppHub />} />
          <Route path="/app/download" element={<AppDownload />} />

          {/* Producer Panel */}
          <Route element={<ProducerLayout />}>
            <Route path="/producer" element={<ProducerDashboard />} />
            <Route path="/producer/dashboard" element={<ProducerDashboard />} />
            <Route path="/producer/events" element={<ProducerEvents />} />
            <Route path="/producer/events/new" element={<ProducerNewEvent />} />
            <Route path="/producer/brand" element={<BrandStudio />} />
            <Route path="/producer/crm" element={<ProducerCRM />} />
            <Route path="/producer/finance" element={<ProducerFinance />} />
            <Route path="/producer/wallet" element={<ProducerWallet />} />
            <Route path="/producer/tables" element={<TableCalculator />} />
            <Route path="/producer/menu" element={<ProducerMenu />} />
          </Route>

          {/* Admin Panel */}
          <Route element={<AdminLayout />}>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
          </Route>

          {/* Checkout */}
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/checkout/payment" element={<CheckoutPayment />} />
          <Route path="/checkout/success" element={<CheckoutSuccess />} />
        </Routes>
      </main>
      {!hideLayout && <Footer />}
    </div>
  )
}

export default function App() {
  return <Layout />
}
