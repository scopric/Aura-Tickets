import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router'
import { Menu, X, Sparkles, CalendarDays, Smartphone, LogIn, UserPlus } from 'lucide-react'
import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const location = useLocation()
  const isProducerRoute = location.pathname.startsWith('/producer')

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = [
    { href: '/', label: 'Inicio', icon: Sparkles },
    { href: '/event/noite-eletro-2025', label: 'Eventos', icon: CalendarDays },
    { href: '/app/download', label: 'App', icon: Smartphone },
  ]

  const isActive = (path: string) => location.pathname === path

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
        isProducerRoute && 'hidden',
        isScrolled
          ? 'glass border-b border-white/20 shadow-elevated'
          : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <img
              src="/images/logo-aura.png"
              alt="Aura"
              className="h-8 w-auto transition-transform duration-300 group-hover:scale-105"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={cn(
                  'relative px-4 py-2 text-sm font-medium transition-colors duration-300 rounded-full',
                  isActive(link.href)
                    ? 'text-plum'
                    : 'text-espresso/60 hover:text-espresso'
                )}
              >
                {isActive(link.href) && (
                  <span className="absolute inset-0 bg-plum/10 rounded-full" />
                )}
                <span className="relative flex items-center gap-2">
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/auth/login"
              className="px-4 py-2.5 text-sm font-medium text-espresso/70 hover:text-espresso border border-espresso/15 hover:border-espresso/30 rounded-full transition-all duration-300 flex items-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Entrar
            </Link>
            <Link
              to="/auth/register"
              className="px-4 py-2.5 text-sm font-medium text-cream bg-plum rounded-full transition-all duration-300 hover:shadow-glow hover:scale-105 flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              Criar Conta
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-espresso"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          'md:hidden overflow-hidden transition-all duration-500',
          isMobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        )}
      >
        <div className="glass border-t border-white/20 px-4 py-4 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors',
                isActive(link.href)
                  ? 'bg-plum/10 text-plum'
                  : 'text-espresso/60 hover:bg-white/50'
              )}
            >
              <link.icon className="w-5 h-5" />
              {link.label}
            </Link>
          ))}
          <div className="flex gap-2 mt-2">
            <Link
              to="/auth/login"
              onClick={() => setIsMobileMenuOpen(false)}
              className="flex-1 flex items-center justify-center px-4 py-3 text-sm font-medium text-espresso border border-espresso/15 rounded-xl"
            >
              Entrar
            </Link>
            <Link
              to="/auth/register"
              onClick={() => setIsMobileMenuOpen(false)}
              className="flex-1 flex items-center justify-center px-4 py-3 text-sm font-medium text-cream bg-plum rounded-xl"
            >
              Criar Conta
            </Link>
          </div>
        </div>
      </div>
    </header>
  )
}
