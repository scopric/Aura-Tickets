import { Outlet, Link, useLocation } from 'react-router'
import { useState } from 'react'
import {
  LayoutDashboard,
  Calendar,
  Palette,
  Users,
  Wallet,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Settings,
  LogOut,
  Calculator,
  Wine
} from 'lucide-react'
import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

const navItems = [
  { to: '/producer/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/producer/events', icon: Calendar, label: 'Eventos' },
  { to: '/producer/tables', icon: Calculator, label: 'Mesas' },
  { to: '/producer/menu', icon: Wine, label: 'Cardapio' },
  { to: '/producer/brand', icon: Palette, label: 'Marca' },
  { to: '/producer/crm', icon: Users, label: 'CRM' },
  { to: '/producer/finance', icon: BarChart3, label: 'Financeiro' },
  { to: '/producer/wallet', icon: Wallet, label: 'Carteira' },
]

export default function ProducerLayout() {
  const [collapsed, setCollapsed] = useState(false)
  const location = useLocation()

  const isActive = (path: string) => location.pathname === path

  return (
    <div className="flex min-h-screen bg-canvas pt-16">
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed left-0 top-0 bottom-0 z-40 bg-[#1a1118] border-r border-white/10 transition-all duration-300 flex flex-col',
          collapsed ? 'w-16' : 'w-60'
        )}
      >
        {/* Logo area */}
        <div className={cn('flex items-center gap-3 px-4 h-16 border-b border-white/10', collapsed && 'justify-center px-2')}>
          <img
            src="/images/logo-aura.png"
            alt="Aura"
            className="h-7 w-auto flex-shrink-0"
          />
          {!collapsed && (
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white tracking-wide">Painel</span>
              <span className="text-[10px] text-plum font-semibold uppercase tracking-wider bg-plum/20 px-2 py-0.5 rounded-full border border-plum/30">Produtor</span>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-2 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] transition-all duration-200 font-medium',
                collapsed ? 'justify-center' : '',
                isActive(item.to)
                  ? 'bg-plum/20 text-plum shadow-[inset_0_0_0_1px_rgba(122,59,105,0.3)]'
                  : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              )}
              title={collapsed ? item.label : undefined}
            >
              <item.icon className="w-[18px] h-[18px] flex-shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          ))}
        </nav>

        {/* Bottom */}
        <div className="p-2 border-t border-white/10 space-y-1">
          <button
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] text-white/50 hover:text-white/90 hover:bg-white/[0.06] transition-all w-full font-medium',
              collapsed && 'justify-center'
            )}
          >
            <Settings className="w-[18px] h-[18px] flex-shrink-0" />
            {!collapsed && <span>Configuracoes</span>}
          </button>
          <button
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] text-white/50 hover:text-red-400 hover:bg-red-500/[0.08] transition-all w-full font-medium',
              collapsed && 'justify-center'
            )}
          >
            <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
            {!collapsed && <span>Sair</span>}
          </button>
        </div>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-plum text-cream flex items-center justify-center shadow-glow hover:scale-110 transition-transform z-50"
        >
          {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>
      </aside>

      {/* Main content */}
      <div className={cn('flex-1 transition-all duration-300 min-h-screen', collapsed ? 'ml-16' : 'ml-60')}>
        <Outlet />
      </div>
    </div>
  )
}
